﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ZedGraph;
//using Tao.Platform;

namespace Terminal
{
    public partial class Form1 : Form
    {
        #region Global variabel

       // int width = 426;
       // int heigth = 378;

        int i = 0;

        string data = "";
        int[] idata = new int[3];
        string[] data_str = new string[25];
        

        
        Int64 tim = 0, tickStart;


               
        #endregion

        public Form1()
        {
            InitializeComponent();
         //   var csv = new StringBuilder();
            sPortAva();
 
           // this.simpleOpenGlControl1.Invalidate();

        }
        
        #region SerialPort
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    data = serialPort1.ReadLine();              //data ditampung sampai ada enter    
                }
                catch { }
                this.Invoke(new EventHandler(parse));
            }
        }

        private void parse(object sender, EventArgs e)
        {
            //Format data
            // #_1_Data1_Data2_Data3_
            
            richTextBoxDataReceived.AppendText(" "+"_"+ data + "\n");
            richTextBoxDataReceived.ScrollToCaret();    //Auto Scrool without click
            // BARU
            ///*
            foreach (string n in data.Split('_'))       //data dipisah dengan character "_"
            {
                if (n == "#")
                    i = 0;
                data_str[i] = n;                        //data yang sudah dipisah disimpan disini
                i++;
            }

            try
            {
                labelTempTGS.Text = data_str[1];
                labelTempWater.Text = data_str[2];
                labelTGS.Text = data_str[3];
                labelLevel.Text = data_str[4];
                }
            catch
            {

            }
            // */

            richTextBoxDataSaved.AppendText(DateTime.Now.ToString("hh.mm.ss.fff")
                + "_" + labelTempTGS.Text + "_" + labelTempWater.Text + "_" + labelTGS.Text
                + "_" + labelLevel.Text
                +"\n");
            richTextBoxDataSaved.ScrollToCaret();    //Auto Scrool without click            
        }

        private void sPortAva()
        {
            string[] serialPort1 = System.IO.Ports.SerialPort.GetPortNames();
            // Display each port name to the console.
            foreach (string item in serialPort1)
            {
               comboBoxCOM.Items.Add(item);
               comboBoxCOM.Text = item;
            }
            
        }
        #endregion main





        #region Grafik

        Int16 xTime = 100;
        private void init_graph()
        {
            
            GraphPane myPaneTGS = zedGraphControlTGS.GraphPane;
            
            
            ///////////////////////////////////////////////////////////////////////////////////// myPaneTGS //////////////////////////////////////
            // myPaneYaw.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneTGS.Title.Text = "";

            myPaneTGS.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneTGS.XAxis.Title.Text = "TGS   Y=ppm   X=Time(Sec)";
            myPaneTGS.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneTGS.YAxis.Title.FontSpec.Size = 16.0f;
            myPaneTGS.YAxis.Title.Text = "";
            //  myPaneTGS.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneTGS.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPaneTGS.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPaneTGS.Fill.Color = System.Drawing.Color.White;
            //myPaneTGS.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listTGS = new RollingPointPairList(500); //Jumlah titik yang digambar titik satu garis

            LineItem curveTGS = myPaneTGS.AddCurve("", listTGS, Color.Blue, SymbolType.None);

            myPaneTGS.XAxis.Scale.Min = 0;

            myPaneTGS.XAxis.Scale.MinorStep = 1;
            myPaneTGS.XAxis.Scale.MajorStep = 5;
            
            }

        Int32 time;
        private void grafik_TGS()
        {

            if (zedGraphControlTGS.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveTGS = zedGraphControlTGS.GraphPane.CurveList[0] as LineItem;

            if (curveTGS == null)
                return;

            IPointListEdit listTGS = curveTGS.Points as IPointListEdit;

            if (listTGS == null)
                return;

            // Time is measured in seconds
            
            time++;//(Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling

            label3.Text = Convert.ToString(Environment.TickCount);
            label4.Text = Convert.ToString(tickStart);
            label5.Text = Convert.ToString(time);

            //listTGS.Add(time, Convert.ToSingle(labelTGS.Text));
            listTGS.Add(time, Convert.ToSingle(labelLevel.Text));
            //label15.Text = Convert.ToString(time);

            

            Scale xScale = zedGraphControlTGS.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlTGS.AxisChange();
            zedGraphControlTGS.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }


        
        /*
        private void SetSize()
        {
            Rectangle formRect = this.ClientRectangle;
            formRect.Inflate(-10, -10);

            if (zedGraphControlYaw.Size != formRect.Size)
            {
                zedGraphControlYaw.Location = formRect.Location;
                zedGraphControlYaw.Size = formRect.Size;
            }
        }
        */

        #endregion

       

        private void timerClock_Tick(object sender, EventArgs e)
        {
            labelTime.Text = DateTime.Now.ToString("dd-MMM-yyyy   hh:mm:ss ");
           // labelGyZ.Text = Convert.ToString(Environment.TickCount);


        }

        #region button_control


        private void buttonSaveData_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "csv files (*.csv)|*.csv";

            saveFileDialog1.FileName = String.Format("Data {0}.csv", DateTime.Now.ToString(" yyy-MMM-dd hh.mm.ss"));

            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK
                && saveFileDialog1.FileName.Length > 0)
            {

                richTextBoxDataSaved.SaveFile(saveFileDialog1.FileName,
                    RichTextBoxStreamType.UnicodePlainText); //jika di save
            }
        }

        private void buttonClearData_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("             Are you sure to clear data?", "Clear data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                richTextBoxDataSaved.Clear();
                richTextBoxDataSaved.Focus();

                richTextBoxDataSaved.AppendText("sep=_\n");
                richTextBoxDataSaved.AppendText("Time_Temp TGS_Temp Water_Kadar  CO2_Level\n");

            }
            else
            {
                this.Activate();
            }
        }


        private void buttonOpenPort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 50;

            serialPort1.PortName = comboBoxCOM.Text;
            serialPort1.BaudRate = Convert.ToInt32(textBox2.Text);
            try
            {
                serialPort1.Open();

                bOpenPort.Enabled = false;
                bStart.Enabled = true;
                buttonRefresh.Enabled = false;
                comboBoxCOM.Enabled = false;
            }
            catch 
            {
                MessageBox.Show("COM Port used by another process");
            }
            //timerRequestData.Enabled = true;
            
        }
        
        private void buttonStart_Click(object sender, EventArgs e)
        {
            richTextBoxDataSaved.AppendText("sep=_\n");
            richTextBoxDataSaved.AppendText("Time_Temp TGS_Temp Water_Kadar  CO2_Level\n");


            if (progressBarIndikator.Value < 100)
            {
                init_graph();
            }

            //timerRequestData.Enabled = true;
            
            timerGraphTGS.Enabled = true;
            
            bStart.Enabled = false;
            bOpenPort.Enabled = false;
            buttonPause.Enabled = true;
            bExit.Enabled = false;
            buttonClosePort.Enabled = false;

            

            progressBarIndikator.Value = 100;
            
        }

        private void buttonPause_Click(object sender, EventArgs e)
        {
            timerRequestData.Enabled = false;
            
            timerGraphTGS.Enabled = false;

            buttonClosePort.Enabled = Enabled;
            bStart.Enabled = true;
            buttonPause.Enabled = false;
            bExit.Enabled = true;

        }

        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("               Have you save your data?\n                    Are you sure to exit? ", "Aplication Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
                //  System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }

        private void buttonClosePort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 0;
            //serialPort1.Write("d");
            serialPort1.Close();
            bOpenPort.Enabled = true;
            buttonClosePort.Enabled = false;

        }


        

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboBoxCOM.Items.Clear();
            comboBoxCOM.Text = "No PORT";
            sPortAva();
        }

        #endregion

        

        private void timerGraphPitch_Tick(object sender, EventArgs e)
        {
            grafik_TGS();

        }


        private void timerRequestData_Tick(object sender, EventArgs e)
        {
            serialPort1.Write("s");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        
    }

}
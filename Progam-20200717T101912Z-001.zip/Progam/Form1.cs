﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ZedGraph;
using Tao.OpenGl;
//using Tao.Platform;


using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using GMap.NET.CacheProviders;
using GMap.NET.MapProviders;

namespace Terminal
{
    public partial class Form1 : Form
    {
        #region Global variabel

       // int width = 426;
       // int heigth = 378;

        int i = 0;

        string data = "";
        int[] idata = new int[3];
        string[] data_str = new string[25];
        int[] data_angle = new int[4];
        int[] data_accelero = new int[4];
        int[] data_gyro = new int[4];
        int[] data_magneto = new int[4];
        double air_speed;
        double altitude;
        double temperature;
        double picth, roll, yaw;
        double fXg, fYg, fZg;

        double base_bmp = 0;
        int base_x_accel;
        int base_y_accel;
        int base_z_accel;

        int base_x_gyro;
        int base_y_gyro;
        int base_z_gyro;
        float base_yaw = 0;
        Int64 tim = 0, tickStart;


                double unfiltered_gyro_angle_x;
        double unfiltered_gyro_angle_y;
        double unfiltered_gyro_angle_z;
        double gyro_angle_x;
        double gyro_angle_y;
        double gyro_angle_z;
        double angle_x;
        double angle_y;
        double angle_z;
        //variable for saving data
        Int64 last_read_time;
        double last_x_angle;  // These are the filtered angles
        double last_y_angle;
        double last_z_angle;
        double last_gyro_x_angle;  // Store the gyro angles to compare drift
        double last_gyro_y_angle;
        double last_gyro_z_angle;
        #endregion

        public Form1()
        {
            InitializeComponent();
            

         //   var csv = new StringBuilder();
            sPortAva();
            initMaps();
            initOpenGl();
 
           // this.simpleOpenGlControl1.Invalidate();
            base_x_accel = 0;
            base_y_accel = 0;
            base_z_accel = 0;
            base_x_gyro = 0;
            base_y_gyro = 0;
            base_z_gyro = 0;
        }
        
        #region SerialPort
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                data = serialPort1.ReadLine();              //data ditampung sampai ada enter     
            }
            this.Invoke(new EventHandler(parse));
        }

        private void parse(object sender, EventArgs e)
        {
            //Format data
            // #_1_Data1_Data2_Data3_
            
            richTextBoxDataReceived.AppendText(" "+"_"+ data + "\n");
            richTextBoxDataReceived.ScrollToCaret();    //Auto Scrool without click
            /*
            // LAMA
            foreach (string n in data.Split('_'))       //data dipisah dengan character "_"
            {
                if (n == "#") 
                    i = 0;
                
                data_str[i] = n;                        //data yang sudah dipisah disimpan disini
                i++;
            }

            if (data_str[1] == "1")            // accelero
            {
                try
                {
                    labelAcX.Text = Convert.ToString(Convert.ToDouble(data_str[2]));
                    labelAcY.Text = Convert.ToString(Convert.ToDouble(data_str[3]));
                    labelAcZ.Text = Convert.ToString(Convert.ToDouble(data_str[4]));
                    labelGyX.Text = Convert.ToString(data_str[5]);
                    labelGyY.Text = Convert.ToString(data_str[6]);
                    labelGyZ.Text = Convert.ToString(data_str[7]);
                    labelMagX.Text = Convert.ToString(data_str[8]);
                    labelMagY.Text = Convert.ToString(data_str[9]);
                    labelMagZ.Text = Convert.ToString(data_str[10]);

                    xRot = Convert.ToSingle(data_str[11]);
                    yRot = Convert.ToSingle(data_str[12]);
                    zRot = Convert.ToSingle(data_str[13]);
                    this.simpleOpenGlControl1.Invalidate();


                    labelRoll.Text = data_str[11];
                    labelPitch.Text = data_str[12];
                    labelYaw.Text = data_str[13];

                    yaw1.yaw_point = Convert.ToSingle(labelYaw.Text);
                    pitch1.pitch = Convert.ToSingle(labelRoll.Text);
                    roll1.rol = -1 * Convert.ToSingle(labelPitch.Text);

                    label_altitude.Text = Convert.ToString((Convert.ToSingle(data_str[14]) - base_bmp).ToString("0.0"));
                    labelAirSpeed.Text = data_str[15];
                }
                catch { }
            }
            else if (data_str[1] == "2")        //  gyro
            {
                try
                {
                    labelTrust.Text = data_str[2];
                    verticalProgressBar1.Value = Convert.ToUInt16(labelTrust.Text);
                }
                catch { }
            }   
            */
          

            // BARU
            ///*
            foreach (string n in data.Split('_'))       //data dipisah dengan character "_"
            {
                if (n == "#")
                    i = 0;

                data_str[i] = n;                        //data yang sudah dipisah disimpan disini
                i++;
            }

            try
            {
                labelAcX.Text = Convert.ToString(Convert.ToDouble(data_str[1]));
                labelAcY.Text = Convert.ToString(Convert.ToDouble(data_str[2]));
                labelAcZ.Text = Convert.ToString(Convert.ToDouble(data_str[3]));
                labelGyX.Text = Convert.ToString(data_str[4]);
                labelGyY.Text = Convert.ToString(data_str[5]);
                labelGyZ.Text = Convert.ToString(data_str[6]);
                labelMagX.Text = Convert.ToString(data_str[7]);
                labelMagY.Text = Convert.ToString(data_str[8]);
                labelMagZ.Text = Convert.ToString(data_str[9]);

                xRot = Convert.ToSingle(data_str[10]);
                yRot = Convert.ToSingle(data_str[11]);
                zRot = Convert.ToSingle(data_str[12]);
                this.simpleOpenGlControl1.Invalidate();


                labelRoll.Text = data_str[10];
                labelPitch.Text = data_str[11];
                labelYaw.Text = data_str[12];
                yaw1.yaw_point = Convert.ToSingle(labelYaw.Text);
                pitch1.pitch = Convert.ToSingle(labelRoll.Text);
                roll1.rol = -1 * Convert.ToSingle(labelPitch.Text);

                label_altitude.Text = Convert.ToString((Convert.ToSingle(data_str[13]) - base_bmp).ToString("0.0"));
                labelAirSpeed.Text = data_str[14];
                labelTrust.Text = data_str[15];
                verticalProgressBar1.Value = Convert.ToUInt16(labelTrust.Text)-97;
            }
            catch
            {

            }
            // */

            richTextBoxDataSaved.AppendText(DateTime.Now.ToString("hh.mm.ss")
                + "_" + labelAcX.Text + "_" + labelAcY.Text + "_" + labelAcZ.Text 
                +"_"+ labelMagX.Text + "_" + labelMagY.Text + "_" + labelMagZ.Text
                + "_" + labelGyX.Text + "_" + labelGyY.Text + "_" + labelGyZ.Text
                + "_" + labelRoll.Text + "_" + labelPitch.Text + "_" + labelYaw.Text
                + "_" + label_altitude.Text + "_" + label_AltitudeCal.Text
                + "_" + labelAirSpeed.Text + "_" + labelAirSpeedGND.Text
                + "_" + labelTrust.Text               
                +"\n");
            richTextBoxDataSaved.ScrollToCaret();    //Auto Scrool without click
        }

        private void sPortAva()
        {
            string[] serialPort1 = System.IO.Ports.SerialPort.GetPortNames();
            // Display each port name to the console.
            foreach (string item in serialPort1)
            {
               comboBoxCOM.Items.Add(item);
               comboBoxCOM.Text = item;
            }
            
        }
        #endregion main




        #region Maps
       

        double curLat, curLng, preLat, preLng;
        GMapRoute rute;

        List<PointLatLng> list = new List<PointLatLng>();
        
        private void Marker(double lati,double longi)
        {
            //MArker
            GMapOverlay markersOverlay = new GMapOverlay("markers");     
            GMarkerGoogle marker = new GMarkerGoogle(new PointLatLng(lati, longi),GMarkerGoogleType.green);
            markersOverlay.Markers.Add(marker);
            gMapControl1.Overlays.Add(markersOverlay);
        }

        private void initMaps()
        {
            //maps config Put in Form Load
            //gMapControl1.MinZoom = 0;
            //gMapControl1.MaxZoom = 24;
            //gMapControl1.Zoom = 9;
            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.ShowCenter = false;
            GMapProvider.WebProxy = new System.Net.WebProxy("proxy3.pens.ac.id", 443);
           // GMapProvider.WebProxy.Credentials = new NetworkCredential("ogrenci@bilgeadam.com", "bilgeada");   

            gMapControl1.MapProvider = GMap.NET.MapProviders.OpenStreetMapProvider.Instance;
            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerAndCache;
            //gMapControl1.SetPositionByKeywords("Jalan Politeknik ITS, Sukolilo, Kota Surabaya, Jawa Timur 60117");
            //gMapControl1.SetPositionByKeywords("New York");

            
            //GMapOverlay markersOverlay = new GMapOverlay("markers");

            gMapControl1.Position = new PointLatLng(-7.276780, 112.794968); //Pusat awal

            





            //Direction
          /*
            PointLatLng start = new PointLatLng(-25.974134, 32.593042);
            PointLatLng end = new PointLatLng(-25.959048, 32.592827);
            MapRoute route = GMap.NET.MapProviders.OpenStreetMapProvider.Instance.GetRoute(
              start, end, false, false, 15);

            GMapRoute r = new GMapRoute(route.Points, "My route");
            GMapOverlay routesOverlay = new GMapOverlay("routes");
            routesOverlay.Routes.Add(r);
            gMapControl1.Overlays.Add(routesOverlay);
            */
            
            //Poligon

            //Plot Route
            GMapOverlay routes = new GMapOverlay("routes");// Constructing object for Overlay
            gMapControl1.Overlays.Add(routes);
            List<PointLatLng> list = new List<PointLatLng>(); // The list of Coordinates to be plotted
            
            list.Add(new PointLatLng(-7.276315, 112.795244));
            Marker(-7.276315, 112.795244);

            list.Add(new PointLatLng(-7.2767657, 112.7949307));
            Marker(-7.2767657, 112.7949307);

            list.Add(new PointLatLng(-7.277150, 112.794963));
            Marker(-7.277150, 112.794963);

            GMapRoute PlotRoute = new GMapRoute(list, "myroute"); // object for routing
            PlotRoute.Stroke.Width = 5;
            PlotRoute.Stroke.Color = Color.Yellow;
            routes.Routes.Add(PlotRoute);



        }
        #endregion


        #region Grafik

        Int16 xTime = 200;
        private void init_graph()
        {
            
            GraphPane myPaneYaw = zedGraphControlYaw.GraphPane;
            GraphPane myPanePicth = zedGraphControlPitch.GraphPane;
            GraphPane myPaneRoll = zedGraphControlRoll.GraphPane;
            GraphPane myPaneAltitude = zedGraphControlAltitude.GraphPane;

            // myPaneYaw.Title.FontSpec.Size = 26.0f;
          //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneYaw.Title.Text = "";
            
            myPaneYaw.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneYaw.XAxis.Title.Text = "YAW   Y=Angle(Deg)   X=Time(Sec)";
            myPaneYaw.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;
        
          //  myPaneYaw.YAxis.Title.FontSpec.Size = 16.0f;
              myPaneYaw.YAxis.Title.Text = "";
          //  myPaneYaw.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;
          
          //  myPaneYaw.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
          // myPaneYaw.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            
            myPaneYaw.Fill.Color = System.Drawing.Color.White;
            //myPaneYaw.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);
            
           RollingPointPairList listYaw = new RollingPointPairList(1000); //Jumlah titik yang digambar titik satu garis

           LineItem curveYaw = myPaneYaw.AddCurve("", listYaw, Color.Blue, SymbolType.None);
            
            myPaneYaw.XAxis.Scale.Min = 0;
            
            myPaneYaw.XAxis.Scale.MinorStep = 1;
            myPaneYaw.XAxis.Scale.MajorStep = 5;
            zedGraphControlYaw.AxisChange();

            ///////////////////////////////////////////////////////////////////////////////////// myPanePicth //////////////////////////////////////
            // myPaneYaw.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPanePicth.Title.Text = "";

            myPanePicth.XAxis.Title.FontSpec.Size = 16.0f;
            myPanePicth.XAxis.Title.Text = "PICTH   Y=Angle(Deg)   X=Time(Sec)";
            myPanePicth.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPanePicth.YAxis.Title.FontSpec.Size = 16.0f;
            myPanePicth.YAxis.Title.Text = "";
            //  myPanePicth.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPanePicth.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPanePicth.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPanePicth.Fill.Color = System.Drawing.Color.White;
            //myPanePicth.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listPicth = new RollingPointPairList(1000); //Jumlah titik yang digambar titik satu garis

            LineItem curvePicth = myPanePicth.AddCurve("", listPicth, Color.Blue, SymbolType.None);

            myPanePicth.XAxis.Scale.Min = 0;

            myPanePicth.XAxis.Scale.MinorStep = 1;
            myPanePicth.XAxis.Scale.MajorStep = 5;
            zedGraphControlYaw.AxisChange();

            ///////////////////////////////////////////////////////////////////////////////////// myPaneRoll //////////////////////////////////////
            // myPaneYaw.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneRoll.Title.Text = "";

            myPaneRoll.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneRoll.XAxis.Title.Text = "ROLL   Y=Angle(Deg)   X=Time(Sec)";
            myPaneRoll.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneRoll.YAxis.Title.FontSpec.Size = 16.0f;
            myPaneRoll.YAxis.Title.Text = "";
            //  myPaneRoll.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneRoll.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPaneRoll.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPaneRoll.Fill.Color = System.Drawing.Color.White;
            //myPaneRoll.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listRoll = new RollingPointPairList(1000); //Jumlah titik yang digambar titik satu garis

            LineItem curveRoll = myPaneRoll.AddCurve("", listRoll, Color.Blue, SymbolType.None);

            myPaneRoll.XAxis.Scale.Min = 0;

            myPaneRoll.XAxis.Scale.MinorStep = 1;
            myPaneRoll.XAxis.Scale.MajorStep = 10;
            zedGraphControlYaw.AxisChange();

            ///////////////////////////////////////////////////////////////////////////////////// myPaneAltitude //////////////////////////////////////
            // myPaneYaw.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneAltitude.Title.Text = "";

            myPaneAltitude.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneAltitude.XAxis.Title.Text = "ALTITUDE   Y=Height(m)   X=Time(Sec)";
            myPaneAltitude.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneAltitude.YAxis.Title.FontSpec.Size = 16.0f;
            myPaneAltitude.YAxis.Title.Text = "";
            //  myPaneAltitude.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneAltitude.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPaneAltitude.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPaneAltitude.Fill.Color = System.Drawing.Color.White;
            //myPaneAltitude.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listAltitude = new RollingPointPairList(1000); //Jumlah titik yang digambar titik satu garis

            LineItem curveAltitude = myPaneAltitude.AddCurve("", listAltitude, Color.Blue, SymbolType.None);

            myPaneAltitude.XAxis.Scale.Min = 0;

            myPaneAltitude.XAxis.Scale.MinorStep = 1;
            myPaneAltitude.XAxis.Scale.MajorStep = 5;
            zedGraphControlYaw.AxisChange();
            
            tickStart = Environment.TickCount;  //waktu mulai
            labelGyX.Text = Convert.ToString(tickStart);
        }

        private void grafik_yaw()
        {

            if (zedGraphControlYaw.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveYaw = zedGraphControlYaw.GraphPane.CurveList[0] as LineItem;

            if (curveYaw == null)
                return;

            IPointListEdit listYaw = curveYaw.Points as IPointListEdit;

            if (listYaw == null)
                return;

            // Time is measured in seconds
            double time = (Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling


            //label15.Text = Convert.ToString(time);

            listYaw.Add(time, Convert.ToSingle(labelYaw.Text));


            Scale xScale = zedGraphControlYaw.GraphPane.XAxis.Scale;

           // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max-xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlYaw.AxisChange();
            zedGraphControlYaw.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }



        private void grafik_Pitch()
        {

            if (zedGraphControlPitch.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curvePitch = zedGraphControlPitch.GraphPane.CurveList[0] as LineItem;

            if (curvePitch == null)
                return;

            IPointListEdit listPitch = curvePitch.Points as IPointListEdit;

            if (listPitch == null)
                return;

            // Time is measured in seconds
            double time = (Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling


            //label15.Text = Convert.ToString(time);

            listPitch.Add(time, Convert.ToSingle(labelPitch.Text));


            Scale xScale = zedGraphControlPitch.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlPitch.AxisChange();
            zedGraphControlPitch.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }

        private void grafik_Roll()
        {

            if (zedGraphControlRoll.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveRoll = zedGraphControlRoll.GraphPane.CurveList[0] as LineItem;

            if (curveRoll == null)
                return;

            IPointListEdit listRoll = curveRoll.Points as IPointListEdit;

            if (listRoll == null)
                return;

            // Time is measured in seconds
            double time = (Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling


          // label15.Text = Convert.ToString(time);

            listRoll.Add(time, Convert.ToSingle(labelRoll.Text));


            Scale xScale = zedGraphControlRoll.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlRoll.AxisChange();
            zedGraphControlRoll.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }

        private void grafik_Altitude()
        {

            if (zedGraphControlAltitude.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveAltitude = zedGraphControlAltitude.GraphPane.CurveList[0] as LineItem;

            if (curveAltitude == null)
                return;

            IPointListEdit listAltitude = curveAltitude.Points as IPointListEdit;

            if (listAltitude == null)
                return;

            // Time is measured in seconds
            double time = (Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling


            ///label15.Text = Convert.ToString(time);

            listAltitude.Add(time,Convert.ToSingle(label_altitude.Text));
            

            Scale xScale = zedGraphControlAltitude.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlAltitude.AxisChange();
            zedGraphControlAltitude.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }
        /*
        private void SetSize()
        {
            Rectangle formRect = this.ClientRectangle;
            formRect.Inflate(-10, -10);

            if (zedGraphControlYaw.Size != formRect.Size)
            {
                zedGraphControlYaw.Location = formRect.Location;
                zedGraphControlYaw.Size = formRect.Size;
            }
        }
        */

        #endregion

        #region 3D
        //openGL TAO
        int width;
        int height;

        private void initOpenGl()
        {
            simpleOpenGlControl1.InitializeContexts();

            //Gl.glClearDepth(1.0);

            Gl.glEnable(Gl.GL_DEPTH_TEST);
            //Gl.glDepthMask(Gl.GL_TRUE);

            Gl.glClearColor(255, 255, 255, 0.5f);	// black background
            width = simpleOpenGlControl1.Width;
            height = simpleOpenGlControl1.Height;
            Gl.glViewport(0, 0, width, height);
            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();
            Glu.gluPerspective(45.0f, (double)width / (double)height, 0.01f, 5000.0f);
            
            //Gl.glEnable(Gl.GL_CULL_FACE);
            //Gl.glEnable(Gl.GL_3D_COLOR_TEXTURE);
            Gl.glCullFace(Gl.GL_BACK);
            
            
        }
        
        float xRot, yRot, zRot;
        private void simpleOpenGlControl1_Paint(object sender, PaintEventArgs e)
        {

            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);

            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();
           
            //Rotation
            Gl.glTranslated(0, -5, -29);  //posisi pada sumbu x,y,z dari gl control  3 1 2
            Gl.glRotated(-xRot, 1, 0, 0);                         //X 2
            //Gl.glRotated(zRot, 0, 1, 0);                                                                               //Z
            Gl.glRotated(0, 0, 1, 0); 
            Gl.glRotated(-yRot, 0, 0, 1);                                                                               //Y1

            Gl.glPointSize(3);
           // Gl.glPolygonMode(Gl.GL_FRONT, Gl.GL_LINES);
           // Gl.glPolygonMode(Gl.GL_BACK, Gl.GL_LINES);
            


            /*  1                     4
             *  ***********************
             *  *                     *
             *  *                     *
             *  *                     *
             *  ***********************
             *  2                     3
            */
            
            ////Rear 1
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 255, 0);
            Gl.glVertex3d(-2, 3, 2);
            Gl.glVertex3d(-2, -1, 2);
            Gl.glVertex3d(2, -1, 2);
            Gl.glVertex3d(2, 3, 2);
            Gl.glEnd();

            ///Miring
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 0, 255);
            Gl.glVertex3d(-2, 6, -2);
            Gl.glVertex3d(-2, 3, 2);
            Gl.glVertex3d(2, 3, 2);
            Gl.glVertex3d(2, 6, -2);
            Gl.glEnd();

            ///Rear 2
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 255, 0);
            Gl.glVertex3d(-2, 12, -2);
            Gl.glVertex3d(-2, 6, -2);
            Gl.glVertex3d(2, 6, -2);
            Gl.glVertex3d(2, 12, -2);
            Gl.glEnd();

            ///Top 1
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 0, 255);
            Gl.glVertex3d(-2, 12, -3);
            Gl.glVertex3d(-2, 12, -2);
            Gl.glVertex3d(2, 12, -2);
            Gl.glVertex3d(2, 12, -3);
            Gl.glEnd();

 
            ////Back
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(0, 255, 255);
            Gl.glVertex3d(-2, 12, -3);
            Gl.glVertex3d(-2, -1, -3);
            Gl.glVertex3d(2, -1, -3);
            Gl.glVertex3d(2, 12, -3);
            Gl.glEnd();
            
            ////Down
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(0, 255, 0);
            Gl.glVertex3d(-2, -1, -3);
            Gl.glVertex3d(-2, -1, 2);
            Gl.glVertex3d(2, -1, 2);
            Gl.glVertex3d(2, -1, -3);
            Gl.glEnd();

            ////Left
            Gl.glBegin(Gl.GL_POLYGON);
            Gl.glColor3ub(255, 200, 0);

            Gl.glVertex3d(-2, -1, -3);
            
            
            Gl.glVertex3d(-2, 12, -3);
            
            Gl.glVertex3d(-2, 12, -2);
            Gl.glVertex3d(-2, 6, -2);
            Gl.glVertex3d(-2, 3, 2);
            Gl.glVertex3d(-2, -1, 2);

            Gl.glEnd();


            ////LEFT BAWAH
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 200, 0);
            Gl.glVertex3d(-2, -1, -3);
            Gl.glVertex3d(-2, -1, -6);
            Gl.glVertex3d(-2, 0, -6);
            Gl.glVertex3d(-2, 0, -3);
            Gl.glEnd();

            ////LEFT ATAS
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 200, 0);
            Gl.glVertex3d(-2, 11, -3);
            Gl.glVertex3d(-2, 11, -6);
            Gl.glVertex3d(-2, 12, -6);
            Gl.glVertex3d(-2, 12, -3);
            Gl.glEnd();


            //RIGHT
            Gl.glBegin(Gl.GL_POLYGON);
            Gl.glColor3ub(255, 200, 0);

            Gl.glVertex3d(2, -1, -3);


            Gl.glVertex3d(2, 12, -3);

            Gl.glVertex3d(2, 12, -2);
            Gl.glVertex3d(2, 6, -2);
            Gl.glVertex3d(2, 3, 2);
            Gl.glVertex3d(2, -1, 2);

            Gl.glEnd();


            ////RIGHT BAWAH
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 200, 0);
            Gl.glVertex3d(2, -1, -3);
            Gl.glVertex3d(2, -1, -6);
            Gl.glVertex3d(2, 0, -6);
            Gl.glVertex3d(2, 0, -3);
            Gl.glEnd();

            ////RIGHT ATAS
            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor3ub(255, 200, 0);
            Gl.glVertex3d(2, 11, -3);
            Gl.glVertex3d(2, 11, -6);
            Gl.glVertex3d(2, 12, -6);
            Gl.glVertex3d(2, 12, -3);
            Gl.glEnd();
            
            Double x, y, z;
            Gl.glBegin(Gl.GL_LINES);
            for (double angle = 0; angle <= 2 * Math.PI; angle += Math.PI / 100)
            {
                x = 8.0 * Math.Cos(angle);
                z = 8.0 * Math.Sin(angle);
                
                
                Gl.glVertex3f((float)(x/1.2),(float)5.5+(float)(z/1.2),-5);
                Gl.glVertex3f((float)x, (float)5.5+(float)z, -5);

            }
            Gl.glEnd();
        }
        #endregion
        



        #region button_control


        private void buttonSaveData_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "csv files (*.csv)|*.csv";

            saveFileDialog1.FileName = String.Format("Data {0}.csv", DateTime.Now.ToString(" yyy-MMM-dd hh.mm.ss"));

            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK
                && saveFileDialog1.FileName.Length > 0)
            {

                richTextBoxDataSaved.SaveFile(saveFileDialog1.FileName,
                    RichTextBoxStreamType.UnicodePlainText); //jika di save
            }
        }

        byte flagClearData = 0;
        private void buttonClearData_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("             Are you sure to clear data?", "Clear data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                richTextBoxDataSaved.Clear();
                richTextBoxDataSaved.Focus();
                flagClearData = 1;
            }
            else
            {
                this.Activate();
            }
        }


        private void buttonOpenPort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 50;

            serialPort1.PortName = comboBoxCOM.Text;
            serialPort1.BaudRate = Convert.ToInt32(textBox2.Text);
            try
            {
                serialPort1.Open();

                bOpenPort.Enabled = false;
                bStart.Enabled = true;
                buttonRefresh.Enabled = false;
                comboBoxCOM.Enabled = false;
            }
            catch 
            {
                MessageBox.Show("COM Port used by another process");
            }
            //timerRequestData.Enabled = true;
            
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (flagClearData == 1 || progressBarIndikator.Value < 100)
            {
                richTextBoxDataSaved.AppendText("sep=_\n");
                richTextBoxDataSaved.AppendText("Time_AccX_AccY_AccZ_GyX_GyY_GyZ_MagX_MaxY_MaxZ_xRot_yRot_zRot_Altitude_Altitude Cal_Air Speed_Air Speed GND_Trush\n");
                flagClearData = 0;
            }

            if (progressBarIndikator.Value < 100)
            {
                init_graph();
            }

            timerRequestData.Enabled = true;
            timerGraphYaw.Enabled = true;
            timerGraphAltitude.Enabled = true;
            timerGraphPitch.Enabled = true;
            timerGraphRoll.Enabled = true;

            bStart.Enabled = false;
            bOpenPort.Enabled = false;
            buttonPause.Enabled = true;
            bExit.Enabled = false;
            bCalibrate.Enabled = true;
            buttonClosePort.Enabled = false;

            progressBarIndikator.Value = 100; 
        }

        private void buttonPause_Click(object sender, EventArgs e)
        {
            timerRequestData.Enabled = false;
            timerGraphYaw.Enabled = false;
            timerGraphAltitude.Enabled = false;
            timerGraphPitch.Enabled = false;
            timerGraphRoll.Enabled = false;

            buttonClosePort.Enabled = Enabled;
            bStart.Enabled = true;
            buttonPause.Enabled = false;
            bExit.Enabled = true;
        }

        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("               Have you save your data?\n                    Are you sure to exit? ", "Aplication Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
                //  System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }

        private void buttonClosePort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 0;
            //serialPort1.Write("d");
            serialPort1.Close();
            bOpenPort.Enabled = true;
            buttonClosePort.Enabled = false;
        }

        
        private void buttonCalibrate_Click(object sender, EventArgs e)
        {
            base_bmp =Convert.ToSingle(label_altitude.Text);
            label_AltitudeCal.Text = Convert.ToString(base_bmp.ToString("0.0"));

        }

        bool check = false;
        data_log form2 = new data_log();
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            check = !check;
            if (check)
                form2.Show();
            else
                form2.Hide();
        }

        

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboBoxCOM.Items.Clear();
            comboBoxCOM.Text = "No PORT";
            sPortAva();
        }

        #endregion

        private void button1_Click_1(object sender, EventArgs e)
        {
            init_graph();           
            timerGraphAltitude.Enabled = true;
            timerRandom.Enabled = true;
        }

        private void timerClock_Tick(object sender, EventArgs e)
        {
            labelTime.Text = DateTime.Now.ToString("dd-MMM-yyyy   hh:mm:ss ");
            // labelGyZ.Text = Convert.ToString(Environment.TickCount);
        }

        private void timerGraphYaw_Tick(object sender, EventArgs e) //Timer penamiplan data pada grafik
        {
            grafik_yaw();
        }

        private void timerGraphRoll_Tick(object sender, EventArgs e)
        {
            grafik_Roll();
        }

        private void timerGraphPitch_Tick(object sender, EventArgs e)
        {
            grafik_Pitch();
        }

        private void timerGraphAltitude_Tick(object sender, EventArgs e)
        {
            grafik_Altitude();
        }

        Random rnd = new Random();
        double randomm;

        private void timerRandom_Tick(object sender, EventArgs e)
        {
            randomm = rnd.NextDouble();
            //label9.Text = Convert.ToString(randomm);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            timerGraphYaw.Enabled = false;
            timerGraphAltitude.Enabled = false;
            timerGraphPitch.Enabled = false;
            timerGraphRoll.Enabled = false;
        }

        private void timerRequestData_Tick(object sender, EventArgs e)
        {
            serialPort1.Write("s");
        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        
    }

}
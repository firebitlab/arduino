﻿namespace Terminal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.timerTanggal = new System.Windows.Forms.Timer(this.components);
            this.label36 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.labelTempTGS = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.labelTempWater = new System.Windows.Forms.Label();
            this.labelTGS = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.bOpenPort = new System.Windows.Forms.Button();
            this.bStart = new System.Windows.Forms.Button();
            this.comboBoxCOM = new System.Windows.Forms.ComboBox();
            this.bExit = new System.Windows.Forms.Button();
            this.buttonPause = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.progressBarIndikator = new System.Windows.Forms.ProgressBar();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonSaveData = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.zedGraphControlTGS = new ZedGraph.ZedGraphControl();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonClearData = new System.Windows.Forms.Button();
            this.timerGraphTGS = new System.Windows.Forms.Timer(this.components);
            this.buttonClosePort = new System.Windows.Forms.Button();
            this.timerRequestData = new System.Windows.Forms.Timer(this.components);
            this.richTextBoxDataReceived = new System.Windows.Forms.RichTextBox();
            this.richTextBoxDataSaved = new System.Windows.Forms.RichTextBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelLevel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM7";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(5, 521);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 16);
            this.label22.TabIndex = 4;
            this.label22.Text = "X";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(6, 537);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 16);
            this.label23.TabIndex = 5;
            this.label23.Text = "Suhu Air";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(5, 554);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 16);
            this.label24.TabIndex = 6;
            this.label24.Text = "Z";
            // 
            // labelTime
            // 
            this.labelTime.BackColor = System.Drawing.Color.Transparent;
            this.labelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.Black;
            this.labelTime.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelTime.Location = new System.Drawing.Point(399, 585);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(149, 22);
            this.labelTime.TabIndex = 39;
            this.labelTime.Text = "16 April 2015    00:00:00";
            this.labelTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(73, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 32);
            this.label7.TabIndex = 48;
            this.label7.Text = "POLITEKNIK ELEKTRONIKA\r\nNEGERI SURABAYA";
            // 
            // timerTanggal
            // 
            this.timerTanggal.Enabled = true;
            this.timerTanggal.Interval = 1;
            this.timerTanggal.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label36.Location = new System.Drawing.Point(5, 521);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 16);
            this.label36.TabIndex = 4;
            this.label36.Text = "Suhu TGS :";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label44.Location = new System.Drawing.Point(5, 554);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(81, 16);
            this.label44.TabIndex = 6;
            this.label44.Text = "Level TGS";
            // 
            // labelTempTGS
            // 
            this.labelTempTGS.AutoSize = true;
            this.labelTempTGS.BackColor = System.Drawing.Color.Transparent;
            this.labelTempTGS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTempTGS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelTempTGS.Location = new System.Drawing.Point(125, 521);
            this.labelTempTGS.Name = "labelTempTGS";
            this.labelTempTGS.Size = new System.Drawing.Size(16, 16);
            this.labelTempTGS.TabIndex = 1;
            this.labelTempTGS.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label46.Location = new System.Drawing.Point(179, 521);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(22, 16);
            this.label46.TabIndex = 49;
            this.label46.Text = "\'C";
            // 
            // labelTempWater
            // 
            this.labelTempWater.AutoSize = true;
            this.labelTempWater.BackColor = System.Drawing.Color.Transparent;
            this.labelTempWater.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTempWater.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelTempWater.Location = new System.Drawing.Point(125, 537);
            this.labelTempWater.Name = "labelTempWater";
            this.labelTempWater.Size = new System.Drawing.Size(16, 16);
            this.labelTempWater.TabIndex = 2;
            this.labelTempWater.Text = "0";
            // 
            // labelTGS
            // 
            this.labelTGS.AutoSize = true;
            this.labelTGS.BackColor = System.Drawing.Color.Transparent;
            this.labelTGS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTGS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelTGS.Location = new System.Drawing.Point(125, 554);
            this.labelTGS.Name = "labelTGS";
            this.labelTGS.Size = new System.Drawing.Size(16, 16);
            this.labelTGS.TabIndex = 3;
            this.labelTGS.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(486, 640);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(48, 21);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "9600";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bOpenPort
            // 
            this.bOpenPort.BackColor = System.Drawing.Color.MidnightBlue;
            this.bOpenPort.FlatAppearance.BorderSize = 3;
            this.bOpenPort.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bOpenPort.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.bOpenPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOpenPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bOpenPort.ForeColor = System.Drawing.Color.White;
            this.bOpenPort.Location = new System.Drawing.Point(540, 613);
            this.bOpenPort.Name = "bOpenPort";
            this.bOpenPort.Size = new System.Drawing.Size(94, 29);
            this.bOpenPort.TabIndex = 4;
            this.bOpenPort.Text = "Open Port";
            this.bOpenPort.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bOpenPort.UseVisualStyleBackColor = false;
            this.bOpenPort.Click += new System.EventHandler(this.buttonOpenPort_Click);
            // 
            // bStart
            // 
            this.bStart.BackColor = System.Drawing.Color.MidnightBlue;
            this.bStart.Enabled = false;
            this.bStart.FlatAppearance.BorderSize = 3;
            this.bStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.bStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bStart.ForeColor = System.Drawing.Color.White;
            this.bStart.Location = new System.Drawing.Point(640, 611);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(69, 29);
            this.bStart.TabIndex = 6;
            this.bStart.Text = "Start";
            this.bStart.UseVisualStyleBackColor = false;
            this.bStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // comboBoxCOM
            // 
            this.comboBoxCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCOM.FormattingEnabled = true;
            this.comboBoxCOM.Location = new System.Drawing.Point(462, 613);
            this.comboBoxCOM.Name = "comboBoxCOM";
            this.comboBoxCOM.Size = new System.Drawing.Size(72, 21);
            this.comboBoxCOM.TabIndex = 21;
            this.comboBoxCOM.Text = "No PORT";
            // 
            // bExit
            // 
            this.bExit.BackColor = System.Drawing.Color.MidnightBlue;
            this.bExit.FlatAppearance.BorderSize = 3;
            this.bExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bExit.ForeColor = System.Drawing.Color.White;
            this.bExit.Location = new System.Drawing.Point(640, 663);
            this.bExit.Name = "bExit";
            this.bExit.Size = new System.Drawing.Size(69, 30);
            this.bExit.TabIndex = 53;
            this.bExit.Text = "Exit";
            this.bExit.UseVisualStyleBackColor = false;
            this.bExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // buttonPause
            // 
            this.buttonPause.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonPause.Enabled = false;
            this.buttonPause.FlatAppearance.BorderSize = 3;
            this.buttonPause.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonPause.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.buttonPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPause.ForeColor = System.Drawing.Color.White;
            this.buttonPause.Location = new System.Drawing.Point(640, 637);
            this.buttonPause.Name = "buttonPause";
            this.buttonPause.Size = new System.Drawing.Size(69, 29);
            this.buttonPause.TabIndex = 54;
            this.buttonPause.Text = "Pause";
            this.buttonPause.UseVisualStyleBackColor = false;
            this.buttonPause.Click += new System.EventHandler(this.buttonPause_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonRefresh.FlatAppearance.BorderSize = 3;
            this.buttonRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRefresh.ForeColor = System.Drawing.Color.White;
            this.buttonRefresh.Location = new System.Drawing.Point(402, 661);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(132, 30);
            this.buttonRefresh.TabIndex = 55;
            this.buttonRefresh.Text = "Refresh Port";
            this.buttonRefresh.UseVisualStyleBackColor = false;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // progressBarIndikator
            // 
            this.progressBarIndikator.Location = new System.Drawing.Point(554, 585);
            this.progressBarIndikator.Name = "progressBarIndikator";
            this.progressBarIndikator.Size = new System.Drawing.Size(151, 22);
            this.progressBarIndikator.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarIndikator.TabIndex = 56;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape8});
            this.shapeContainer1.Size = new System.Drawing.Size(720, 697);
            this.shapeContainer1.TabIndex = 64;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.BackColor = System.Drawing.Color.White;
            this.rectangleShape8.BorderColor = System.Drawing.Color.Black;
            this.rectangleShape8.FillColor = System.Drawing.SystemColors.ControlLightLight;
            this.rectangleShape8.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape8.Location = new System.Drawing.Point(5, 5);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(703, 55);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(399, 617);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 65;
            this.label8.Text = "COM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(399, 642);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 16);
            this.label14.TabIndex = 66;
            this.label14.Text = "Baud Rate";
            // 
            // buttonSaveData
            // 
            this.buttonSaveData.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonSaveData.FlatAppearance.BorderSize = 3;
            this.buttonSaveData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonSaveData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonSaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveData.ForeColor = System.Drawing.Color.White;
            this.buttonSaveData.Location = new System.Drawing.Point(13, 662);
            this.buttonSaveData.Name = "buttonSaveData";
            this.buttonSaveData.Size = new System.Drawing.Size(112, 30);
            this.buttonSaveData.TabIndex = 67;
            this.buttonSaveData.Text = "Save Data";
            this.buttonSaveData.UseVisualStyleBackColor = false;
            this.buttonSaveData.Click += new System.EventHandler(this.buttonSaveData_Click);
            // 
            // zedGraphControlTGS
            // 
            this.zedGraphControlTGS.AutoScroll = true;
            this.zedGraphControlTGS.BackColor = System.Drawing.Color.White;
            this.zedGraphControlTGS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.zedGraphControlTGS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zedGraphControlTGS.ForeColor = System.Drawing.Color.SteelBlue;
            this.zedGraphControlTGS.IsAutoScrollRange = true;
            this.zedGraphControlTGS.IsShowHScrollBar = true;
            this.zedGraphControlTGS.IsShowVScrollBar = true;
            this.zedGraphControlTGS.Location = new System.Drawing.Point(7, 69);
            this.zedGraphControlTGS.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.zedGraphControlTGS.Name = "zedGraphControlTGS";
            this.zedGraphControlTGS.ScrollGrace = 0D;
            this.zedGraphControlTGS.ScrollMaxX = 0D;
            this.zedGraphControlTGS.ScrollMaxY = 0D;
            this.zedGraphControlTGS.ScrollMaxY2 = 0D;
            this.zedGraphControlTGS.ScrollMinX = 0D;
            this.zedGraphControlTGS.ScrollMinY = 0D;
            this.zedGraphControlTGS.ScrollMinY2 = 0D;
            this.zedGraphControlTGS.SelectModifierKeys = System.Windows.Forms.Keys.None;
            this.zedGraphControlTGS.Size = new System.Drawing.Size(702, 447);
            this.zedGraphControlTGS.TabIndex = 65;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::Terminal.Properties.Resources.logo_pens;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 48);
            this.pictureBox2.TabIndex = 47;
            this.pictureBox2.TabStop = false;
            // 
            // buttonClearData
            // 
            this.buttonClearData.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonClearData.FlatAppearance.BorderSize = 3;
            this.buttonClearData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonClearData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonClearData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClearData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClearData.ForeColor = System.Drawing.Color.White;
            this.buttonClearData.Location = new System.Drawing.Point(131, 663);
            this.buttonClearData.Name = "buttonClearData";
            this.buttonClearData.Size = new System.Drawing.Size(111, 31);
            this.buttonClearData.TabIndex = 69;
            this.buttonClearData.Text = "Clear Data";
            this.buttonClearData.UseVisualStyleBackColor = false;
            this.buttonClearData.Click += new System.EventHandler(this.buttonClearData_Click_1);
            // 
            // timerGraphTGS
            // 
            this.timerGraphTGS.Interval = 1000;
            this.timerGraphTGS.Tick += new System.EventHandler(this.timerGraphPitch_Tick);
            // 
            // buttonClosePort
            // 
            this.buttonClosePort.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonClosePort.Enabled = false;
            this.buttonClosePort.FlatAppearance.BorderSize = 3;
            this.buttonClosePort.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonClosePort.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.buttonClosePort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClosePort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClosePort.ForeColor = System.Drawing.Color.White;
            this.buttonClosePort.Location = new System.Drawing.Point(540, 663);
            this.buttonClosePort.Name = "buttonClosePort";
            this.buttonClosePort.Size = new System.Drawing.Size(94, 29);
            this.buttonClosePort.TabIndex = 71;
            this.buttonClosePort.Text = "Close Port";
            this.buttonClosePort.UseVisualStyleBackColor = false;
            this.buttonClosePort.Click += new System.EventHandler(this.buttonClosePort_Click);
            // 
            // timerRequestData
            // 
            this.timerRequestData.Interval = 200;
            this.timerRequestData.Tick += new System.EventHandler(this.timerRequestData_Tick);
            // 
            // richTextBoxDataReceived
            // 
            this.richTextBoxDataReceived.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBoxDataReceived.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxDataReceived.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBoxDataReceived.Location = new System.Drawing.Point(-2, 0);
            this.richTextBoxDataReceived.Name = "richTextBoxDataReceived";
            this.richTextBoxDataReceived.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxDataReceived.Size = new System.Drawing.Size(374, 49);
            this.richTextBoxDataReceived.TabIndex = 74;
            this.richTextBoxDataReceived.Text = "";
            // 
            // richTextBoxDataSaved
            // 
            this.richTextBoxDataSaved.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBoxDataSaved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxDataSaved.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBoxDataSaved.Location = new System.Drawing.Point(-4, 0);
            this.richTextBoxDataSaved.Name = "richTextBoxDataSaved";
            this.richTextBoxDataSaved.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxDataSaved.Size = new System.Drawing.Size(376, 49);
            this.richTextBoxDataSaved.TabIndex = 87;
            this.richTextBoxDataSaved.Text = "";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Location = new System.Drawing.Point(13, 586);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(380, 75);
            this.tabControl3.TabIndex = 89;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.richTextBoxDataSaved);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(372, 49);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Terminal Save";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.richTextBoxDataReceived);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(372, 49);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Terminal Received";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(179, 537);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 16);
            this.label1.TabIndex = 90;
            this.label1.Text = "\'C";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(179, 554);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 91;
            this.label2.Text = "ppm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(404, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 92;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(402, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 93;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(404, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 94;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(283, 522);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 16);
            this.label6.TabIndex = 95;
            this.label6.Text = "Level Air ADC :";
            // 
            // labelLevel
            // 
            this.labelLevel.AutoSize = true;
            this.labelLevel.BackColor = System.Drawing.Color.Transparent;
            this.labelLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLevel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelLevel.Location = new System.Drawing.Point(404, 522);
            this.labelLevel.Name = "labelLevel";
            this.labelLevel.Size = new System.Drawing.Size(16, 16);
            this.labelLevel.TabIndex = 96;
            this.labelLevel.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(720, 697);
            this.ControlBox = false;
            this.Controls.Add(this.labelLevel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.zedGraphControlTGS);
            this.Controls.Add(this.tabControl3);
            this.Controls.Add(this.bExit);
            this.Controls.Add(this.buttonClosePort);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.buttonClearData);
            this.Controls.Add(this.buttonSaveData);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.progressBarIndikator);
            this.Controls.Add(this.buttonRefresh);
            this.Controls.Add(this.buttonPause);
            this.Controls.Add(this.comboBoxCOM);
            this.Controls.Add(this.bStart);
            this.Controls.Add(this.bOpenPort);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.labelTGS);
            this.Controls.Add(this.labelTempWater);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.labelTempTGS);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.shapeContainer1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Final Project 2015 V 1.0";
            this.TransparencyKey = System.Drawing.Color.Gold;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        //private Tao.Platform.Windows.SimpleOpenGlControl simpleOpenGlControl1;
        //private G05U_Control.Roll roll1;
        //private G05U_Control.Yaw yaw1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        //private G05U_Control.Pitch pitch1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timerTanggal;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label labelTempTGS;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label labelTempWater;
        private System.Windows.Forms.Label labelTGS;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button bOpenPort;
        private System.Windows.Forms.Button bStart;
        private System.Windows.Forms.ComboBox comboBoxCOM;
        private System.Windows.Forms.Button bExit;
        private System.Windows.Forms.Button buttonPause;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.ProgressBar progressBarIndikator;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private System.Windows.Forms.Button buttonSaveData;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private ZedGraph.ZedGraphControl zedGraphControlTGS;
        private System.Windows.Forms.Button buttonClearData;
        private System.Windows.Forms.Timer timerGraphTGS;
        private System.Windows.Forms.Button buttonClosePort;
        private System.Windows.Forms.Timer timerRequestData;
        private System.Windows.Forms.RichTextBox richTextBoxDataReceived;
        private System.Windows.Forms.RichTextBox richTextBoxDataSaved;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelLevel;
    }
}


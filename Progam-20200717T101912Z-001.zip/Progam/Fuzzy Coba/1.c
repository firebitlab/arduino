/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.3 Standard
Automatic Program Generator
� Copyright 1998-2011 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 22/05/2015
Author  : Agus
Company : pens.ac.id
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 16,000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 256
*****************************************************/



#include <mega32.h>

#include <delay.h>
// Standard Input/Output functions
#include <stdio.h>


#define Timer01ms    TCCR0  
#define START       0x03   
#define STOP        0x00


///MOTOR///
#define dirKa PORTD.0 
#define remKa PORTD.3

//BUZZER//
#define buzzer PORTC.4

void CW()
{
    dirKa=1;
    remKa=1;
}

void CCW()
{
    dirKa=0;
    remKa=1;
}

//-------------INTETRUPT START
unsigned int RPMtick=0;
// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
// Place your code here
++RPMtick;
}


//PID time sampling 100mS
int PIDsetPoint=30,PIDerror,PIDpv;
float PIDpOut,PIDiOut,PIDdOut;
float PIDkp=0.26,PIDki,PIDkd;

unsigned int tick1mS=0;
int RPM;
// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
// Place your code here
++tick1mS;
if (tick1mS==100)
    {
        tick1mS=0;
        RPM=RPMtick;    
        printf("#_%d_\n",RPM);       
        RPMtick=0; 
        
        //P Controller
//        PIDpv=RPM;
//        PIDerror=PIDsetPoint-PIDpv; 
//        PIDpOut=PIDkp*PIDerror;
//        OCR1A=OCR1A + PIDpOut;
    }
}
//-----------INTERUPT END


unsigned char lcdBuff[20];
// Alphanumeric LCD functions
#include <alcd.h>

void initAVR()
{
// Declare your local variables here

PORTA=0x00;
DDRA=0xFF;

PORTB=0xFF;
DDRB=0x00;

PORTC=0x10;
DDRC=0x10;

PORTD=0x00;
DDRD=0b11111011;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 250.000 kHz
// Mode: Normal top=0xFF
// OC0 output: Disconnected
//
TCNT0=0x05;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 2000.000 kHz
// Mode: Fast PWM top=ICR1
// OC1A output: Inverted
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off

TCCR1A=0xC2;
TCCR1B=0x1A;
TCNT1H=0x00;
TCNT1L=0x00;

ICR1H=0x01;
ICR1L=0xF4;

//OCR1AH=0x01;
//OCR1AL=0xF4;
//OCR1A=0;
//OCR1BH=0x00;
//OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Rising Edge
// INT1: Off
// INT2: Off
GICR|=0x40;
MCUCR=0x03;
MCUCSR=0x00;
GIFR=0x40;;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x01;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x67;

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTC Bit 7
// RD - PORTC Bit 6
// EN - PORTC Bit 5
// D4 - PORTC Bit 3
// D5 - PORTC Bit 2
// D6 - PORTC Bit 1
// D7 - PORTC Bit 0
// Characters/line: 16
lcd_init(16);

// Global enable interrupts
#asm("sei")

}
unsigned char masukan=0;
//unsigned char


float and(float a1, float a2)
{
  return(a1<a2?a1:a2);
}

float or(float a1, float a2)
{
  return(a1>a2?a1:a2);
}

float MF(float input, float a, float b, float c)
{
  if(input<a||input>c) return 0;
  else if(input<b) return (input-a)/(b-a);  //menghitung DOM jika nilai i<titik tengah segitiga
  else return (c-input)/(c-b);              //menghitung DOM jika nilai i>titik tengah segitiga
}

float Fuzzy(float e)
{
  /*
  Program Kontroler Logika Fuzzy, EruP(c)2011-2015
  */
  static float LastError=0;
  float de;                  // delta error
  float ePB, ePM, ePS, eZ, eNS, eNM, eNB;
  float dPB, dPM, dPS, dZ, dNS, dNM, dNB;
  float oNH, oNB, oNM, oNS, oZ, oPS, oPM, oPB, oPH;
  float Out;
  
  
  #define poPH 255      // point of Output Positive Huge tone
  #define poPB 150      // point of Output Positive Big tone
  #define poPM 100      // point of Output Positive Medium tone
  #define poPS 50       // point of Output Positive Small tone
  #define poZ 0         // point of Output Zero tone
  #define poNS -50      // point of Output Negative Small tone
  #define poNM -100     // point of Output Negative Medium tone
  #define poNB -150     // point of Output Negative Big tone
  #define poNH -255     // point of Output Negative Huge tone

  de = e - LastError;
  LastError = e;
  
  // calculate fuzzy value using fuzzyfication based on membership function
  
  // calculate membership function for error signal
  // float MF(float input, float a, float b, float c) 
  #define pePB 32      // point Error Positive Big
  #define pePM 30      // point Error Positive Medium
  #define pePS 28      // point Error Positive Small
  #define peZ  26      // point Error Zero
  #define peNS 24      // point Error Negative Small
  #define peNM 22      // point Error Negative Medium
  #define peNB 20      // point Error Negative Big
  
  ePB=MF(e,pePM,pePB,36);  // Fungsi keanggotaan Positive Big untuk Error
  ePM=MF(e,pePS,pePM,pePB);  // Fungsi keanggotaan Positive Medium untuk Error
  ePS=MF(e,peZ,pePS,pePM);   // Fungsi keanggotaan Positive Small untuk Error
  eZ =MF(e,peNS,peZ,pePS);   // Fungsi keanggotaan Zero untuk Error
  eNS=MF(e,peNM,peNS,peZ);   // Fungsi keanggotaan Negative Small untuk Error
  eNM=MF(e,peNB,peNM,peNS);  // Fungsi keanggotaan Negative Medium untuk Error
  eNB=MF(e,16,peNB,peNM); // Fungsi keanggotaan Negative Big untuk Error
   
  // calculate membership function for delta error  
   
  #define pdPB 64      // point Delta Error Positive Big
  #define pdPM 60      // point Delta Error Positive Medium
  #define pdPS 58      // point Delta Error Positive Small
  #define pdZ  52      // point Delta Error Zero
  #define pdNS 48      // point Delta Error Negative Small
  #define pdNM 44      // point Delta Error Negative Medium
  #define pdNB 40      // point Delta Error Negative Big 
  
  dPB=MF(de,pdPM,pdPB,72);  // Fungsi keanggotaan Positive Big untuk Delta Error
  dPM=MF(de,pdPS,pdPM,pdPB);  // Fungsi keanggotaan Positive Medium untuk Delta Error
  dPS=MF(de,pdZ,pdPS,pdPM);   // Fungsi keanggotaan Positive Small untuk Delta Error
  dZ =MF(de,pdNS,pdZ,pdPS);   // Fungsi keanggotaan Zero untuk Delta Error
  dNS=MF(de,pdNM,pdNS,pdZ);   // Fungsi keanggotaan Negative Small untuk Delta Error
  dNM=MF(de,pdNB,pdNM,pdNS ); // Fungsi keanggotaan Negative Medium untuk Delta Error
  dNB=MF(de,32,pdNB,pdNM); // Fungsi keanggotaan Negative Big untuk Delta Error
  
  lcd_gotoxy(0,0);
  sprintf(lcdBuff,"%.1f",ePB);
  lcd_puts(lcdBuff); 
  
  lcd_gotoxy(4,0);
  sprintf(lcdBuff,"%.1f",ePM);
  lcd_puts(lcdBuff);
   
  lcd_gotoxy(8,0);
  sprintf(lcdBuff,"%.1f",ePS);
  lcd_puts(lcdBuff); 
  
  lcd_gotoxy(12,0);
  sprintf(lcdBuff,"%.1f",eZ);
  lcd_puts(lcdBuff); 
  
  lcd_gotoxy(0,1);
  sprintf(lcdBuff,"%.1f",eNS);
  lcd_puts(lcdBuff); 
  
  lcd_gotoxy(4,1);
  sprintf(lcdBuff,"%.1f",eNM);
  lcd_puts(lcdBuff);
   
  lcd_gotoxy(8,1);
  sprintf(lcdBuff,"%.1f",eNB);
  lcd_puts(lcdBuff); 
  
  
  // do inference engine using IF-THEN rule base
  /*
  oPH = or(and(ePB,dPS),or(and(ePM,dPM),or(and(ePS,dPB),or(and(ePB,dPM),or(and(ePM,dPB),and(ePB,dPB))))));
  oPB = or(and(ePB,dZ),or(and(ePM,dPS),or(and(ePS,dPM),and(eZ,dPB))));
  oPM = or(and(ePB,dNS),or(and(ePM,dZ),or(and(ePS,dPS),or(and(eZ,dPM),and(eNS,dPB)))));
  oPS = or(and(ePB,dNM),or(and(ePM,dNS),or(and(ePS,dZ),or(and(eZ,dPS),or(and(eNS,dPM),and(eNM,dPB))))));
  oZ  = or(and(ePB,dNB),or(and(ePM,dNM),or(and(ePS,dNS),or(and(eZ,dZ),or(and(eNS,dPS),or(and(eNM,dPM),and(eNB,dPB)))))));
  oNS = or(and(ePM,dNB),or(and(ePS,dNM),or(and(eZ,dNS),or(and(eNS,dZ),or(and(eNM,dPS),and(eNB,dPM))))));
  oNM = or(and(ePS,dNB),or(and(eZ,dNM),or(and(eNS,dNS),or(and(eNM,dZ),and(eNB,dPB)))));
  oNB = or(and(eZ,dNB),or(and(eNS,dNM),or(and(eNM,dNS),(and(eNB,dZ)))));
  oNH = or(and(eNS,dNB),or(and(eNM,dNM),or(and(eNB,dNS),or(and(eNM,dNB),or(and(eNB,dNM),and(eNB,dNB))))));
  */
  
  // calculate crisp value using defuzzyfication
//  Out=(oNH*poNH+oNB*poNB+oNM*poNM+oNS*poNS+oZ*poZ+oPS*poPS+oPM*poPM+oPB*poPB+oPH*poPH)/(oNH+oNB+oNM+oNS+oZ+oPS+oPM+oPB+oPH);
//  return Out;
}

int coba(int n)
{
    int a;
    a=2*n;
    return a; 
}

int agus;
#define ERROR 156;

void main(void)
{
  float SettingPoint=25;
  float ErrorSekarang, DeltaError, ErrorLama=0;

initAVR();
/*
lcd_gotoxy(0,0);
lcd_putsf("FUZZY");  
lcd_gotoxy(0,1);
sprintf(lcdBuff,"PV=%3d",masukan);
lcd_puts(lcdBuff);

//OCR1A=alfia;
//lcd_gotoxy(6,0);
//sprintf(lcdBuff,"OCR1A=%3d",OCR1A);

lcd_gotoxy(6,0);
sprintf(lcdBuff,"DOM= ",masukan);
lcd_puts(lcdBuff);
lcd_gotoxy(5,1);
lcd_putsf("%");
delay_ms(1000);
*/
CW();
          
Timer01ms=START;

while (1)
      {
      if(PINB.1==0)
        {   
            masukan++; 
            delay_ms(250);
            if (masukan>36)
            masukan=36;            
        }
        
        if(PINB.2==0)
        {   
            masukan--;
            delay_ms(250);
            if (masukan<16)
            masukan=16;
        } 
        
        if(PINB.3==0)
        {   
            masukan=26;
        } 
        
        if (masukan==100) 
        {
            buzzer=0;
        } 
        
         if (masukan<100) 
        {
            buzzer=1;
        } 
//        OCR1A=alfia*5;
//        lcd_gotoxy(6,0);

                                           
        //ErrorSekarang=SettingPoint-masukan;             // Error=[-2000,2000] rpm
        //DeltaError=ErrorSekarang-ErrorLama;             // ini hanya digunakan untuk monitoring di PC
        //ErrorLama=ErrorSekarang;                        // DE yang sesungguhnya dilakukan di fungsi Fuzzy
        
        lcd_gotoxy(13,1);
        sprintf(lcdBuff,"%2d",masukan);
        lcd_puts(lcdBuff); 
        
        Fuzzy(masukan);  
        
     /*
        lcd_gotoxy(6,0);
        sprintf(lcdBuff,"DOM=%3d",agus);
        lcd_puts(lcdBuff); 
        
        lcd_gotoxy(0,1);
        sprintf(lcdBuff,"PV=%3d",masukan);
        lcd_puts(lcdBuff); 
        lcd_gotoxy(5,1);
        lcd_putsf("%"); 
        
      sprintf(lcdBuff,"RPS=%3d ",RPM);
      lcd_gotoxy(9,1);
      lcd_puts(lcdBuff);   */  
      
      delay_ms(100);
      }  

}

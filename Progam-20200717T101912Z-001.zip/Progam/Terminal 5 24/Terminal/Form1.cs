﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ZedGraph;

namespace Terminal
{
    public partial class Form1 : Form
    {
        #region Global variabel

       // int width = 426;
       // int heigth = 378;

        int i = 0;

        string data = "";
        int[] idata = new int[3];
        string[] data_str = new string[25];
        

        
        Int64 tim = 0, tickStart;


               
        #endregion

        public Form1()
        {
            InitializeComponent();
            //   var csv = new StringBuilder();
            sPortAva();
 
           // this.simpleOpenGlControl1.Invalidate();
        }
        
        #region SerialPort
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    data = serialPort1.ReadLine();              //data ditampung sampai ada enter    
                }
                catch { }
                this.Invoke(new EventHandler(parse));
            }
        }

        private void parse(object sender, EventArgs e)
        {
            
            richTextBoxDataReceived.AppendText(" "+"_"+ data + "\n");
            richTextBoxDataReceived.ScrollToCaret();    //Auto Scrool without click
            
            foreach (string n in data.Split('_'))       //data dipisah dengan character "_"
            {
                if (n == "#")
                    i = 0;
                data_str[i] = n;                        //data yang sudah dipisah disimpan disini
                i++;
            }

            try
            {
                labelSuhuLingkungan.Text = data_str[1];
                labelSuhuAir.Text = data_str[2];
                labelSetPoint.Text=data_str[3];
                labelError.Text=data_str[4];
                labelDeltaError.Text = data_str[5];
                labelLevelAir.Text = data_str[6];
                labelOCR.Text = data_str[7];

                verticalProgressBarLevelAir.Value = Convert.ToInt16(data_str[6]);
            }
            catch
            {

            }

            //printf("#_%.1f_%.1f_%.1f_%.1f_%.1f_%d_\n",temperatureTGS,temperatureWater,SetPoint,ErrorSekarang,DeltaError,LvlData); 
            
            richTextBoxDataSaved.AppendText(DateTime.Now.ToString("hh.mm.ss.fff")

                + "_" + labelSuhuLingkungan.Text + "_" + labelSuhuAir.Text + "_" + labelSetPoint.Text
                + "_" + labelError.Text + "_" + labelDeltaError.Text + "_" + labelLevelAir.Text
                + "_" + labelOCR.Text
                +"\n");

            richTextBoxDataSaved.ScrollToCaret();    //Auto Scrool without click            
        }

        private void sPortAva()
        {
            string[] serialPort1 = System.IO.Ports.SerialPort.GetPortNames();
            // Display each port name to the console.
            foreach (string item in serialPort1)
            {
               comboBoxCOM.Items.Add(item);
               comboBoxCOM.Text = item;
            }          
        }
        #endregion serial Port

        #region Grafik

        Int16 xTime = 100;
        
        private void init_graph()
        {
             
            ///////////////////////////////////////////////////////////////////////////////////// myPaneSuhuAir //////////////////////////////////////
            GraphPane myPaneSuhuAir = zedGraphControlSuhuAir.GraphPane;
            myPaneSuhuAir.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneSuhuAir.Title.Text = "Grafik Perbandingan Suhu dengan Set Point";

            myPaneSuhuAir.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneSuhuAir.XAxis.Title.Text = "Blue=Suhu Air °C   Red=Set Point °C X=Time(Sec)";
            myPaneSuhuAir.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneSuhuAir.YAxis.Title.FontSpec.Size = 24.0f;
            myPaneSuhuAir.YAxis.Title.Text = "";
            //  myPaneSuhuAir.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneSuhuAir.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPaneSuhuAir.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPaneSuhuAir.Fill.Color = System.Drawing.Color.White;
            //myPaneSuhuAir.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listSuhuAir = new RollingPointPairList(500); //Jumlah titik yang digambar titik satu garis
            RollingPointPairList listSetPoint = new RollingPointPairList(500); //Jumlah titik yang digambar titik satu garis

            LineItem curveSuhuAir = myPaneSuhuAir.AddCurve("", listSuhuAir, Color.Blue, SymbolType.None);
            LineItem curveSetPoint = myPaneSuhuAir.AddCurve("", listSetPoint, Color.Red, SymbolType.None);


            myPaneSuhuAir.XAxis.Scale.Min = 0;
            myPaneSuhuAir.XAxis.Scale.MinorStep = 1;
            myPaneSuhuAir.XAxis.Scale.MajorStep = 5;
                        
            ///////////////////////////////////////////////////////////////////////////////////// myPaneFuzzy //////////////////////////////////////
            GraphPane myPaneFuzzy = zedGraphControlFuzzy.GraphPane;
            myPaneFuzzy.Title.FontSpec.Size = 26.0f;
            //  myPaneYaw.Title.FontSpec.FontColor = System.Drawing.Color.Black;
            myPaneFuzzy.Title.Text = "Grafik Perbandingan Error dan Delta Error";

            myPaneFuzzy.XAxis.Title.FontSpec.Size = 16.0f;
            myPaneFuzzy.XAxis.Title.Text = "Blue=Error   Red=Delta Error   X=Time(Sec)";
            myPaneFuzzy.XAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneFuzzy.YAxis.Title.FontSpec.Size = 16.0f;
            myPaneFuzzy.YAxis.Title.Text = "";
            //  myPaneFuzzy.YAxis.Title.FontSpec.FontColor = System.Drawing.Color.Black;

            //  myPaneFuzzy.YAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;
            // myPaneFuzzy.XAxis.Scale.FontSpec.FontColor = System.Drawing.Color.Black;

            myPaneFuzzy.Fill.Color = System.Drawing.Color.White;
            //myPaneFuzzy.Chart.Fill.Brush = new System.Drawing.SolidBrush(Color.White);

            RollingPointPairList listError = new RollingPointPairList(500); //Jumlah titik yang digambar titik satu garis
            RollingPointPairList listDeltaError = new RollingPointPairList(500); //Jumlah titik yang digambar titik satu garis


            LineItem curveError = myPaneFuzzy.AddCurve("", listError, Color.Blue, SymbolType.None);
            LineItem curveDeltaError = myPaneFuzzy.AddCurve("", listDeltaError, Color.Red, SymbolType.None);

            myPaneFuzzy.XAxis.Scale.Min = 0;
            myPaneFuzzy.XAxis.Scale.MinorStep = 1;
            myPaneFuzzy.XAxis.Scale.MajorStep = 5;
            
            }

        Int32 time;
        private void grafik_SuhuAir()
        {
/*
            if (zedGraphControlSuhuAir.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveSuhuAir = zedGraphControlSuhuAir.GraphPane.CurveList[0] as LineItem;

            if (curveSuhuAir == null)
                return;

            IPointListEdit listSuhuAir = curveSuhuAir.Points as IPointListEdit;

            if (listSuhuAir == null)
                return;

            // Time is measured in seconds
            
            time++;//(Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling

            //label3.Text = Convert.ToString(Environment.TickCount);
            //label4.Text = Convert.ToString(tickStart);
            //label5.Text = Convert.ToString(time);

            listSuhuAir.Add(time, Convert.ToSingle(labelSuhuAir.Text));
            //listSuhuAir.Add(time, Convert.ToSingle(trackBar1.Value * 2));
            //label15.Text = Convert.ToString(time);

            

            Scale xScale = zedGraphControlSuhuAir.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlSuhuAir.AxisChange();
            zedGraphControlSuhuAir.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
 */
            if (zedGraphControlSuhuAir.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveSuhuAir = zedGraphControlSuhuAir.GraphPane.CurveList[0] as LineItem;
            LineItem curveSetPoint = zedGraphControlSuhuAir.GraphPane.CurveList[1] as LineItem;

            if (curveSuhuAir == null)
                return;

            if (curveSetPoint == null)
                return;

            IPointListEdit listSuhuAir = curveSuhuAir.Points as IPointListEdit;
            IPointListEdit listSetPoint = curveSetPoint.Points as IPointListEdit;

            if (listSuhuAir == null)
                return;

            if (listSetPoint == null)
                return;
            // Time is measured in seconds

            time++;//(Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling

            //label3.Text = Convert.ToString(Environment.TickCount);
            //label4.Text = Convert.ToString(tickStart);
            //label5.Text = Convert.ToString(time);

            listSuhuAir.Add(time, Convert.ToSingle(labelSuhuAir.Text));
            listSetPoint.Add(time, Convert.ToSingle(labelSetPoint.Text));

            //listSuhuAir.Add(time, Convert.ToSingle("25"));
            //listSetPoint.Add(time, Convert.ToSingle("26"));

            //listSuhuAir.Add(time, Convert.ToSingle(trackBar1.Value));
            //listSetPoint.Add(time, Convert.ToSingle(trackBar1.Value*3));
            //label15.Text = Convert.ToString(time);



            Scale xScale = zedGraphControlSuhuAir.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlSuhuAir.AxisChange();
            zedGraphControlSuhuAir.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }

        private void grafik_Fuzzy()
        {

            if (zedGraphControlFuzzy.GraphPane.CurveList.Count <= 0)
                return;
            LineItem curveError = zedGraphControlFuzzy.GraphPane.CurveList[0] as LineItem;
            LineItem curveDeltaError = zedGraphControlFuzzy.GraphPane.CurveList[1] as LineItem;

            if (curveError == null)
                return;

            if (curveDeltaError == null)
                return;

            IPointListEdit listError= curveError.Points as IPointListEdit;
            IPointListEdit listDeltaError = curveDeltaError.Points as IPointListEdit;

            if (listError == null)
                return;

            if (listDeltaError == null)
                return;
            // Time is measured in seconds

            time++;//(Environment.TickCount - tickStart) / xTime; //sama dengan waktu sampling

            //label3.Text = Convert.ToString(Environment.TickCount);
            //label4.Text = Convert.ToString(tickStart);
            //label5.Text = Convert.ToString(time);

            listError.Add(time, Convert.ToSingle(labelError.Text));
            listDeltaError.Add(time, Convert.ToSingle(labelDeltaError.Text));

            //listError.Add(time, Convert.ToSingle(trackBar1.Value));
            //listDeltaError.Add(time, Convert.ToSingle(trackBar1.Value*3));
            //label15.Text = Convert.ToString(time);



            Scale xScale = zedGraphControlFuzzy.GraphPane.XAxis.Scale;

            // label10.Text = Convert.ToString(xScale.Max - xScale.MajorStep);


            if (time > xScale.Max - xScale.MajorStep)
            {
                xScale.Max = time + xScale.MajorStep;
                xScale.Min = xScale.Max - xTime; //6 jumlah titik pada sumbu x
            }

            zedGraphControlFuzzy.AxisChange();
            zedGraphControlFuzzy.Invalidate(); //Menggerakan sumbu x,y jika ada perubahan nilai
        }


        
        /*
        private void SetSize()
        {
            Rectangle formRect = this.ClientRectangle;
            formRect.Inflate(-10, -10);

            if (zedGraphControlYaw.Size != formRect.Size)
            {
                zedGraphControlYaw.Location = formRect.Location;
                zedGraphControlYaw.Size = formRect.Size;
            }
        }
        */

        #endregion

       

        private void timerClock_Tick(object sender, EventArgs e)
        {
            labelTime.Text = DateTime.Now.ToString("dd-MMM-yyyy   hh:mm:ss ");
           // labelGyZ.Text = Convert.ToString(Environment.TickCount);


        }

        #region button_control


        private void buttonSaveData_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "csv files (*.csv)|*.csv";

            saveFileDialog1.FileName = String.Format("Data {0}.csv", DateTime.Now.ToString(" yyy-MMM-dd hh.mm.ss"));

            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK
                && saveFileDialog1.FileName.Length > 0)
            {

                richTextBoxDataSaved.SaveFile(saveFileDialog1.FileName,
                    RichTextBoxStreamType.UnicodePlainText); //jika di save
            }
        }

        private void buttonClearData_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("             Are you sure to clear data?", "Clear data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                richTextBoxDataSaved.Clear();
                richTextBoxDataSaved.Focus();

                richTextBoxDataSaved.AppendText("sep=_\n");
                richTextBoxDataSaved.AppendText("Waktu_Suhu Lingkungan_Suhu Air_Set Point_Error_Delta Error_Level_OCR\n");

            }
            else
            {
                this.Activate();
            }
        }


        private void buttonOpenPort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 50;

            serialPort1.PortName = comboBoxCOM.Text;
            serialPort1.BaudRate = Convert.ToInt32(textBox2.Text);
            try
            {
                serialPort1.Open();

                bOpenPort.Enabled = false;
                bStart.Enabled = true;
                buttonRefresh.Enabled = false;
                comboBoxCOM.Enabled = false;
            }
            catch 
            {
                MessageBox.Show("COM Port used by another process");
            }
            //timerRequestData.Enabled = true;
            
        }
        
        private void buttonStart_Click(object sender, EventArgs e)
        {
            richTextBoxDataSaved.AppendText("sep=_\n");
            richTextBoxDataSaved.AppendText("Waktu_Suhu Lingkungan_Suhu Air_Set Point_Error_Delta Error_Level_OCR\n");


            if (progressBarIndikator.Value < 100)
            {
                init_graph();
            }

            //timerRequestData.Enabled = true;
            
            timerGraphTGS.Enabled = true;
            
            bStart.Enabled = false;
            bOpenPort.Enabled = false;
            buttonPause.Enabled = true;
            bExit.Enabled = false;
            buttonClosePort.Enabled = false;

            

            progressBarIndikator.Value = 100;
            
        }

        private void buttonPause_Click(object sender, EventArgs e)
        {
            timerRequestData.Enabled = false;
            
            timerGraphTGS.Enabled = false;

            buttonClosePort.Enabled = Enabled;
            bStart.Enabled = true;
            buttonPause.Enabled = false;
            bExit.Enabled = true;

        }

        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("               Have you save your data?\n                    Are you sure to exit? ", "Aplication Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
                //  System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
        }

        private void buttonClosePort_Click(object sender, EventArgs e)
        {
            progressBarIndikator.Value = 0;
            //serialPort1.Write("d");
            serialPort1.Close();
            bOpenPort.Enabled = true;
            buttonClosePort.Enabled = false;

        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboBoxCOM.Items.Clear();
            comboBoxCOM.Text = "No PORT";
            sPortAva();
        }

        #endregion

        

        private void timerGraphPitch_Tick(object sender, EventArgs e)
        {
            grafik_SuhuAir();
            grafik_Fuzzy();

        }


        private void timerRequestData_Tick(object sender, EventArgs e)
        {
            serialPort1.Write("s");
        }


        private void button1_Click(object sender, EventArgs e)
        {
            init_graph();
        }

        private void rectangleShape8_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void zedGraphControlSuhuAir_Load(object sender, EventArgs e)
        {

        }

        private void zedGraphControlFuzzy_Load(object sender, EventArgs e)
        {

        }
        
    }

}
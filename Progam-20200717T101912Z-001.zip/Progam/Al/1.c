/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.0 Evaluation
Automatic Program Generator
� Copyright 1998-2010 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 12/13/2015
Author  : Freeware, for evaluation and non-commercial use only
Company : 
Comments: 


Chip type               : ATmega16
Program type            : Application
AVR Core Clock frequency: 16.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 256
*****************************************************/


#include <mega16.h>
#include <delay.h>

//-------------------------  VARIABEL
#define ON    1
#define OFF   0

#define PUMP                PORTD.6
#define BATAS_BAWAH_AIR     464 //5cm
#define BATAS_ATAS_AIR      536 //7cm

#define AERATOR             PORTD.5
#define COOLER              PORTD.4

#define tombolUp    PINB.0
#define tombolDown  PINB.1
#define tombolOk    PINB.2

#define ditekan     0
#define tidakDitekan     1


#define inTGSdata    read_adc(7)

#define inLeveldata  read_adc(6) 
//variabel regresi
#define regresiA    -18.047
#define regresiB    0.047
float leveldataCm;

//-------------------
#ifndef RXB8
#define RXB8 1
#endif

#ifndef TXB8
#define TXB8 0
#endif

#ifndef UPE
#define UPE 2
#endif

#ifndef DOR
#define DOR 3
#endif

#ifndef FE
#define FE 4
#endif

#ifndef UDRE
#define UDRE 5
#endif

#ifndef RXC
#define RXC 7
#endif

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<DOR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)


// USART Receiver buffer
#define RX_BUFFER_SIZE 8
char rx_buffer[RX_BUFFER_SIZE];

#if RX_BUFFER_SIZE <= 256
unsigned char rx_wr_index,rx_rd_index,rx_counter;
#else
unsigned int rx_wr_index,rx_rd_index,rx_counter;
#endif

// This flag is set on USART Receiver buffer overflow
bit rx_buffer_overflow;

// USART Receiver interrupt service routine
interrupt [USART_RXC] void usart_rx_isr(void)
{
char status,data;
status=UCSRA;
data=UDR;
if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
   {
   rx_buffer[rx_wr_index++]=data;
#if RX_BUFFER_SIZE == 256
   // special case for receiver buffer size=256
   if (++rx_counter == 0)
      {
#else
   if (rx_wr_index == RX_BUFFER_SIZE) rx_wr_index=0;
   if (++rx_counter == RX_BUFFER_SIZE)
      {
      rx_counter=0;
#endif
      rx_buffer_overflow=1;
      }
   }
}

#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
char getchar(void)
{
char data;
while (rx_counter==0);
data=rx_buffer[rx_rd_index++];
#if RX_BUFFER_SIZE != 256
if (rx_rd_index == RX_BUFFER_SIZE) rx_rd_index=0;
#endif
#asm("cli")
--rx_counter;
#asm("sei")
return data;
}
#pragma used-
#endif

// Standard Input/Output functions
#include <stdio.h>



// Alphanumeric LCD Module functions
#include <alcd.h>
char lcd_buffer[33];

//------------------------------------------------------//
// FUNGSI-FUNGSI UNTUK DS18B0 V1.1 ATO
// 1.LIHAT KODE ADDRESS SENSOR DS NYA DENGAN FUNGSI CHECK
// 2.GANTI addess sesuai yang tertera
// 3.
//------------------------------------------------------//

// 1 Wire Bus interface functions
#include <1wire.h>
// DS1820 Temperature Sensor functions
#include <ds18b20.h>

char addressDSWATER[9]={0x28,0xff,0xfC,0x30,0x90,0x15,0x03,0x5E};    
char addressDSTGS[9]={0x28,0xff,0x8f,0xc9,0x4c,0x04,0x00,0xf7};
float temperatureTGS, temperatureWater;

/* maximum number of DS18B20 connected to the 1 Wire bus */
#define MAX_DEVICES 8
/* DS18B20 devices ROM code storage area */
unsigned char rom_code[MAX_DEVICES][9];
unsigned char i,j,devices;


//DS18B20_9BIT_RES 0  // 9 bit thermometer resolution
//DS18B20_10BIT_RES 1 // 10 bit thermometer resolution
//DS18B20_11BIT_RES 2 // 11 bit thermometer resolution
//DS18B20_12BIT_RES 3 // 12 bit thermometer resolution
#define DS18B20_TEMPLOWER   20
#define DS18B20_TEMPUPPER   30

void ds18b20Init()
{

    /* detect how many DS18B20 devices
    are connected to the 1 Wire bus */
    devices=w1_search(0xf0,rom_code);
    /* configure each DS18B20 device for 12 bit temperature
   measurement resolution */
    //NOT WORK
    //ds18b20_init(addressDSWATER,DS18B20_TEMPLOWER,DS18B20_TEMPUPPER,DS18B20_12BIT_RES);
    //ds18b20_init(addressDSWATER,DS18B20_TEMPLOWER,DS18B20_TEMPUPPER,DS18B20_12BIT_RES);

}

void ds18b20CheckAddress()
{
    /* display the ROM codes for each device */
if (devices)
   {
   for (i=0;i<devices;i++)
       {
       sprintf(lcd_buffer,"#%u is:",i+1);
       lcd_clear();
       lcd_puts(lcd_buffer);
       delay_ms(2000);
       lcd_clear();
       for (j=0;j<8;j++)
           {
           sprintf(lcd_buffer,"%02X ",rom_code[i][j]);
           lcd_puts(lcd_buffer);
           if (j==3) lcd_gotoxy(0,1);
           };
       delay_ms(5000);
       };
   }
else
while (1); /* stop here if no devices were found */
}

void ds18b20GetData()
{
    /* measure and display the temperature(s) */   
    temperatureWater= ds18b20_temperature(addressDSWATER);
    if(temperatureWater<-10)
    temperatureWater=0;
    
    temperatureTGS= ds18b20_temperature(addressDSTGS);
    if(temperatureTGS<-10)
    temperatureTGS=0;
    
    // Butuh delay
    //delay_ms(1000);
}
//------------------------------------------------------//
//DS18B20 SELESAI
//------------------------------------------------------//


//------------------------------------------------------//
//ADC START
//------------------------------------------------------//

#define ADC_VREF_TYPE 0x00

// Read the AD conversion result
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;
return ADCW;
}

//------------------------------------------------------//
//ADC SELESAI
//------------------------------------------------------//



//------------------------------------------------------//
//INTERRUPT
//------------------------------------------------------//


//C2F6  1
//E17A  0.5
//F0BC  0.25
#define MYTCNT1H    0xf0    
#define MYTCNT1L    0xbc
unsigned int TGSData,LvlData;
// Timer1 overflow interrupt service routine
interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
// Reinitialize Timer1 value
TCNT1H=MYTCNT1H;
TCNT1L=MYTCNT1L;
//Put Your Code Here
//ds18b20GetData();      
}

//------------------------------------------------------//
//INTERRUPT SELESAI
//------------------------------------------------------//







void ioInit()
{

PORTA=0x00;
DDRA=0x00;

PORTB=0xFF;
DDRB=0x00;

PORTC=0x00;
DDRC=0x00;

PORTD=0x00;
DDRD=0xFF;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=0xFF
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 15.625 kHz
// Mode: Normal top=0xFFFF
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: On
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
//TCCR1A=0x00;
//TCCR1B=0x05;

TCNT1H=MYTCNT1H;
TCNT1L=MYTCNT1L;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x05;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0x98;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x67;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 1000.000 kHz
// ADC Voltage Reference: AREF pin
// ADC Auto Trigger Source: ADC Stopped
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x84;

// SPI initialization
// SPI disabled
SPCR=0x00;

// TWI initialization
// TWI disabled
TWCR=0x00;

// 1 Wire Bus initialization
// 1 Wire Data port: PORTA
// 1 Wire Data bit: 0
// Note: 1 Wire port settings must be specified in the
// Project|Configure|C Compiler|Libraries|1 Wire IDE menu.

    w1_init();
    

// Alphanumeric LCD initialization
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTC Bit 7
// RD - PORTC Bit 6
// EN - PORTC Bit 5
// D4 - PORTC Bit 3
// D5 - PORTC Bit 2
// D6 - PORTC Bit 1
// D7 - PORTC Bit 0
// Characters/line: 16
lcd_init(16);

// Global enable interrupts
#asm("sei")



PUMP=OFF;
AERATOR=OFF;
}




void main(void)
{

ioInit();
ds18b20Init();


//printf("sep=_\n");
//printf("temperatureTGS_temperatureWater_TGSData\n");
while (1)
      {
       
        ds18b20GetData();
        sprintf(lcd_buffer,"T%.1f\xdfC",temperatureTGS);  
        lcd_gotoxy(0,0);
        lcd_puts(lcd_buffer);
        
        sprintf(lcd_buffer,"W%.1f\xdfC",temperatureWater);  
        lcd_gotoxy(8,0);
        lcd_puts(lcd_buffer);
        
        
        TGSData=inTGSdata;
        LvlData=inLeveldata;
        leveldataCm=regresiA+regresiB*LvlData;
 
        
        
        sprintf(lcd_buffer,"TD=%4d LV=%.1f",TGSData,leveldataCm); // String to form the output 
        lcd_gotoxy(0,1);
        lcd_puts(lcd_buffer);
                
        printf("#_%.1f_%.1f_%d_%d_%.1f_\n",temperatureTGS,temperatureWater,TGSData,LvlData,leveldataCm                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            );
        
        
        if (LvlData< BATAS_BAWAH_AIR )
           { PUMP=ON;
            //AERATOR=ON;
            }
            
        if (LvlData> BATAS_ATAS_AIR )
            {
            PUMP=OFF;
            //AERATOR=OFF;
            }
        
        //PUMP=ON;
        delay_ms(400);
        
        //AERATOR
        AERATOR=ON; 
        delay_ms(500);
//        AERATOR=OFF;
//        delay_ms(500); 
        
        //COLOLER       
        //COOLER=ON; 
        //delay_ms(1000);
        //COOLER=OFF;
        //delay_ms(1000);
         
        //lcd_clear();
        //putchar(getchar());
          
      }
  
}

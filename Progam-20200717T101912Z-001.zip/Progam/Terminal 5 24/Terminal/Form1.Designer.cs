﻿namespace Terminal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label23 = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.timerTanggal = new System.Windows.Forms.Timer(this.components);
            this.labelSuhuAir = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.bOpenPort = new System.Windows.Forms.Button();
            this.bStart = new System.Windows.Forms.Button();
            this.comboBoxCOM = new System.Windows.Forms.ComboBox();
            this.bExit = new System.Windows.Forms.Button();
            this.buttonPause = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.progressBarIndikator = new System.Windows.Forms.ProgressBar();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonSaveData = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.zedGraphControlSuhuAir = new ZedGraph.ZedGraphControl();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonClearData = new System.Windows.Forms.Button();
            this.timerGraphTGS = new System.Windows.Forms.Timer(this.components);
            this.buttonClosePort = new System.Windows.Forms.Button();
            this.timerRequestData = new System.Windows.Forms.Timer(this.components);
            this.richTextBoxDataReceived = new System.Windows.Forms.RichTextBox();
            this.richTextBoxDataSaved = new System.Windows.Forms.RichTextBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelLevelAir = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelError = new System.Windows.Forms.Label();
            this.labelDeltaError = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.labelSuhuLingkungan = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.zedGraphControlFuzzy = new ZedGraph.ZedGraphControl();
            this.label2 = new System.Windows.Forms.Label();
            this.labelSetPoint = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.verticalProgressBarLevelAir = new VerticalProgressBar.VerticalProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelOCR = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM7";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(12, 521);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(211, 20);
            this.label23.TabIndex = 5;
            this.label23.Text = "Suhu air dengan kontrol :";
            // 
            // labelTime
            // 
            this.labelTime.BackColor = System.Drawing.Color.White;
            this.labelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.ForeColor = System.Drawing.Color.Black;
            this.labelTime.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelTime.Location = new System.Drawing.Point(626, 535);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(169, 44);
            this.labelTime.TabIndex = 39;
            this.labelTime.Text = "16 April 2015    00:00:00";
            this.labelTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(212, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(415, 20);
            this.label7.TabIndex = 48;
            this.label7.Text = "POLITEKNIK ELEKTRONIKA NEGERI SURABAYA";
            // 
            // timerTanggal
            // 
            this.timerTanggal.Enabled = true;
            this.timerTanggal.Interval = 1;
            this.timerTanggal.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // labelSuhuAir
            // 
            this.labelSuhuAir.AutoSize = true;
            this.labelSuhuAir.BackColor = System.Drawing.Color.Transparent;
            this.labelSuhuAir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuhuAir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelSuhuAir.Location = new System.Drawing.Point(225, 521);
            this.labelSuhuAir.Name = "labelSuhuAir";
            this.labelSuhuAir.Size = new System.Drawing.Size(19, 20);
            this.labelSuhuAir.TabIndex = 2;
            this.labelSuhuAir.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(558, 56);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(48, 21);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "9600";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bOpenPort
            // 
            this.bOpenPort.BackColor = System.Drawing.Color.MidnightBlue;
            this.bOpenPort.FlatAppearance.BorderSize = 3;
            this.bOpenPort.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bOpenPort.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.bOpenPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOpenPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bOpenPort.ForeColor = System.Drawing.Color.White;
            this.bOpenPort.Location = new System.Drawing.Point(617, 26);
            this.bOpenPort.Name = "bOpenPort";
            this.bOpenPort.Size = new System.Drawing.Size(94, 53);
            this.bOpenPort.TabIndex = 4;
            this.bOpenPort.Text = "Open Port";
            this.bOpenPort.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bOpenPort.UseVisualStyleBackColor = false;
            this.bOpenPort.Click += new System.EventHandler(this.buttonOpenPort_Click);
            // 
            // bStart
            // 
            this.bStart.BackColor = System.Drawing.Color.MidnightBlue;
            this.bStart.Enabled = false;
            this.bStart.FlatAppearance.BorderSize = 3;
            this.bStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.bStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bStart.ForeColor = System.Drawing.Color.White;
            this.bStart.Location = new System.Drawing.Point(717, 29);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(74, 29);
            this.bStart.TabIndex = 6;
            this.bStart.Text = "Start";
            this.bStart.UseVisualStyleBackColor = false;
            this.bStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // comboBoxCOM
            // 
            this.comboBoxCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCOM.FormattingEnabled = true;
            this.comboBoxCOM.Location = new System.Drawing.Point(534, 29);
            this.comboBoxCOM.Name = "comboBoxCOM";
            this.comboBoxCOM.Size = new System.Drawing.Size(72, 21);
            this.comboBoxCOM.TabIndex = 21;
            this.comboBoxCOM.Text = "No PORT";
            // 
            // bExit
            // 
            this.bExit.BackColor = System.Drawing.Color.MidnightBlue;
            this.bExit.FlatAppearance.BorderSize = 3;
            this.bExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.bExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bExit.ForeColor = System.Drawing.Color.White;
            this.bExit.Location = new System.Drawing.Point(717, 81);
            this.bExit.Name = "bExit";
            this.bExit.Size = new System.Drawing.Size(74, 30);
            this.bExit.TabIndex = 53;
            this.bExit.Text = "Exit";
            this.bExit.UseVisualStyleBackColor = false;
            this.bExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // buttonPause
            // 
            this.buttonPause.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonPause.Enabled = false;
            this.buttonPause.FlatAppearance.BorderSize = 3;
            this.buttonPause.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonPause.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.buttonPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPause.ForeColor = System.Drawing.Color.White;
            this.buttonPause.Location = new System.Drawing.Point(717, 55);
            this.buttonPause.Name = "buttonPause";
            this.buttonPause.Size = new System.Drawing.Size(74, 29);
            this.buttonPause.TabIndex = 54;
            this.buttonPause.Text = "Pause";
            this.buttonPause.UseVisualStyleBackColor = false;
            this.buttonPause.Click += new System.EventHandler(this.buttonPause_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonRefresh.FlatAppearance.BorderSize = 3;
            this.buttonRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRefresh.ForeColor = System.Drawing.Color.White;
            this.buttonRefresh.Location = new System.Drawing.Point(471, 79);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(140, 30);
            this.buttonRefresh.TabIndex = 55;
            this.buttonRefresh.Text = "Refresh Port";
            this.buttonRefresh.UseVisualStyleBackColor = false;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // progressBarIndikator
            // 
            this.progressBarIndikator.Location = new System.Drawing.Point(474, 4);
            this.progressBarIndikator.Name = "progressBarIndikator";
            this.progressBarIndikator.Size = new System.Drawing.Size(317, 21);
            this.progressBarIndikator.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarIndikator.TabIndex = 56;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape8});
            this.shapeContainer1.Size = new System.Drawing.Size(800, 697);
            this.shapeContainer1.TabIndex = 64;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.BackColor = System.Drawing.Color.White;
            this.rectangleShape8.BorderColor = System.Drawing.Color.Black;
            this.rectangleShape8.FillColor = System.Drawing.SystemColors.ControlLightLight;
            this.rectangleShape8.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape8.Location = new System.Drawing.Point(5, 5);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(788, 80);
            this.rectangleShape8.Click += new System.EventHandler(this.rectangleShape8_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(471, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 65;
            this.label8.Text = "COM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(471, 58);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 16);
            this.label14.TabIndex = 66;
            this.label14.Text = "Baud Rate";
            // 
            // buttonSaveData
            // 
            this.buttonSaveData.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonSaveData.FlatAppearance.BorderSize = 3;
            this.buttonSaveData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonSaveData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonSaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveData.ForeColor = System.Drawing.Color.White;
            this.buttonSaveData.Location = new System.Drawing.Point(5, 79);
            this.buttonSaveData.Name = "buttonSaveData";
            this.buttonSaveData.Size = new System.Drawing.Size(112, 30);
            this.buttonSaveData.TabIndex = 67;
            this.buttonSaveData.Text = "Save Data";
            this.buttonSaveData.UseVisualStyleBackColor = false;
            this.buttonSaveData.Click += new System.EventHandler(this.buttonSaveData_Click);
            // 
            // zedGraphControlSuhuAir
            // 
            this.zedGraphControlSuhuAir.AutoScroll = true;
            this.zedGraphControlSuhuAir.BackColor = System.Drawing.Color.White;
            this.zedGraphControlSuhuAir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.zedGraphControlSuhuAir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zedGraphControlSuhuAir.ForeColor = System.Drawing.Color.SteelBlue;
            this.zedGraphControlSuhuAir.IsAutoScrollRange = true;
            this.zedGraphControlSuhuAir.IsShowHScrollBar = true;
            this.zedGraphControlSuhuAir.IsShowVScrollBar = true;
            this.zedGraphControlSuhuAir.Location = new System.Drawing.Point(7, 91);
            this.zedGraphControlSuhuAir.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.zedGraphControlSuhuAir.Name = "zedGraphControlSuhuAir";
            this.zedGraphControlSuhuAir.ScrollGrace = 0D;
            this.zedGraphControlSuhuAir.ScrollMaxX = 0D;
            this.zedGraphControlSuhuAir.ScrollMaxY = 0D;
            this.zedGraphControlSuhuAir.ScrollMaxY2 = 0D;
            this.zedGraphControlSuhuAir.ScrollMinX = 0D;
            this.zedGraphControlSuhuAir.ScrollMinY = 0D;
            this.zedGraphControlSuhuAir.ScrollMinY2 = 0D;
            this.zedGraphControlSuhuAir.SelectModifierKeys = System.Windows.Forms.Keys.None;
            this.zedGraphControlSuhuAir.Size = new System.Drawing.Size(390, 400);
            this.zedGraphControlSuhuAir.TabIndex = 65;
            this.zedGraphControlSuhuAir.Load += new System.EventHandler(this.zedGraphControlSuhuAir_Load);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::Terminal.Properties.Resources.logo_pens;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 70);
            this.pictureBox2.TabIndex = 47;
            this.pictureBox2.TabStop = false;
            // 
            // buttonClearData
            // 
            this.buttonClearData.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonClearData.FlatAppearance.BorderSize = 3;
            this.buttonClearData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonClearData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.buttonClearData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClearData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClearData.ForeColor = System.Drawing.Color.White;
            this.buttonClearData.Location = new System.Drawing.Point(123, 79);
            this.buttonClearData.Name = "buttonClearData";
            this.buttonClearData.Size = new System.Drawing.Size(111, 31);
            this.buttonClearData.TabIndex = 69;
            this.buttonClearData.Text = "Clear Data";
            this.buttonClearData.UseVisualStyleBackColor = false;
            this.buttonClearData.Click += new System.EventHandler(this.buttonClearData_Click_1);
            // 
            // timerGraphTGS
            // 
            this.timerGraphTGS.Enabled = true;
            this.timerGraphTGS.Interval = 1000;
            this.timerGraphTGS.Tick += new System.EventHandler(this.timerGraphPitch_Tick);
            // 
            // buttonClosePort
            // 
            this.buttonClosePort.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonClosePort.Enabled = false;
            this.buttonClosePort.FlatAppearance.BorderSize = 3;
            this.buttonClosePort.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.buttonClosePort.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.buttonClosePort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClosePort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClosePort.ForeColor = System.Drawing.Color.White;
            this.buttonClosePort.Location = new System.Drawing.Point(617, 81);
            this.buttonClosePort.Name = "buttonClosePort";
            this.buttonClosePort.Size = new System.Drawing.Size(94, 29);
            this.buttonClosePort.TabIndex = 71;
            this.buttonClosePort.Text = "Close Port";
            this.buttonClosePort.UseVisualStyleBackColor = false;
            this.buttonClosePort.Click += new System.EventHandler(this.buttonClosePort_Click);
            // 
            // timerRequestData
            // 
            this.timerRequestData.Interval = 200;
            this.timerRequestData.Tick += new System.EventHandler(this.timerRequestData_Tick);
            // 
            // richTextBoxDataReceived
            // 
            this.richTextBoxDataReceived.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBoxDataReceived.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxDataReceived.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBoxDataReceived.Location = new System.Drawing.Point(-2, 0);
            this.richTextBoxDataReceived.Name = "richTextBoxDataReceived";
            this.richTextBoxDataReceived.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxDataReceived.Size = new System.Drawing.Size(440, 49);
            this.richTextBoxDataReceived.TabIndex = 74;
            this.richTextBoxDataReceived.Text = "";
            // 
            // richTextBoxDataSaved
            // 
            this.richTextBoxDataSaved.BackColor = System.Drawing.SystemColors.MenuText;
            this.richTextBoxDataSaved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxDataSaved.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBoxDataSaved.Location = new System.Drawing.Point(-4, 0);
            this.richTextBoxDataSaved.Name = "richTextBoxDataSaved";
            this.richTextBoxDataSaved.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxDataSaved.Size = new System.Drawing.Size(460, 49);
            this.richTextBoxDataSaved.TabIndex = 87;
            this.richTextBoxDataSaved.Text = "";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Location = new System.Drawing.Point(5, 4);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(446, 75);
            this.tabControl3.TabIndex = 89;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.richTextBoxDataSaved);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(438, 49);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Terminal Save";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.richTextBoxDataReceived);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(438, 49);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Terminal Received";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(268, 521);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 20);
            this.label1.TabIndex = 90;
            this.label1.Text = "°C";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(12, 545);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 20);
            this.label6.TabIndex = 95;
            this.label6.Text = "Level air (Ultrasonic) :";
            // 
            // labelLevelAir
            // 
            this.labelLevelAir.AutoSize = true;
            this.labelLevelAir.BackColor = System.Drawing.Color.Transparent;
            this.labelLevelAir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLevelAir.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelLevelAir.Location = new System.Drawing.Point(225, 545);
            this.labelLevelAir.Name = "labelLevelAir";
            this.labelLevelAir.Size = new System.Drawing.Size(19, 20);
            this.labelLevelAir.TabIndex = 96;
            this.labelLevelAir.Text = "0";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl3);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.comboBoxCOM);
            this.panel1.Controls.Add(this.bOpenPort);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.buttonSaveData);
            this.panel1.Controls.Add(this.buttonClearData);
            this.panel1.Controls.Add(this.progressBarIndikator);
            this.panel1.Controls.Add(this.bStart);
            this.panel1.Controls.Add(this.buttonPause);
            this.panel1.Controls.Add(this.bExit);
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.buttonClosePort);
            this.panel1.Location = new System.Drawing.Point(3, 582);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(794, 112);
            this.panel1.TabIndex = 97;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(268, 545);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 20);
            this.label9.TabIndex = 98;
            this.label9.Text = "cm";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(411, 521);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 20);
            this.label10.TabIndex = 99;
            this.label10.Text = "Error :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(411, 545);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 20);
            this.label11.TabIndex = 100;
            this.label11.Text = "Delta error :";
            // 
            // labelError
            // 
            this.labelError.AutoSize = true;
            this.labelError.BackColor = System.Drawing.Color.Transparent;
            this.labelError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelError.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelError.Location = new System.Drawing.Point(557, 521);
            this.labelError.Name = "labelError";
            this.labelError.Size = new System.Drawing.Size(19, 20);
            this.labelError.TabIndex = 101;
            this.labelError.Text = "0";
            // 
            // labelDeltaError
            // 
            this.labelDeltaError.AutoSize = true;
            this.labelDeltaError.BackColor = System.Drawing.Color.Transparent;
            this.labelDeltaError.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDeltaError.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelDeltaError.Location = new System.Drawing.Point(557, 545);
            this.labelDeltaError.Name = "labelDeltaError";
            this.labelDeltaError.Size = new System.Drawing.Size(19, 20);
            this.labelDeltaError.TabIndex = 102;
            this.labelDeltaError.Text = "0";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label46.Location = new System.Drawing.Point(268, 497);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(27, 20);
            this.label46.TabIndex = 49;
            this.label46.Text = "°C";
            // 
            // labelSuhuLingkungan
            // 
            this.labelSuhuLingkungan.AutoSize = true;
            this.labelSuhuLingkungan.BackColor = System.Drawing.Color.Transparent;
            this.labelSuhuLingkungan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuhuLingkungan.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelSuhuLingkungan.Location = new System.Drawing.Point(225, 497);
            this.labelSuhuLingkungan.Name = "labelSuhuLingkungan";
            this.labelSuhuLingkungan.Size = new System.Drawing.Size(19, 20);
            this.labelSuhuLingkungan.TabIndex = 1;
            this.labelSuhuLingkungan.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label36.Location = new System.Drawing.Point(13, 497);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(197, 20);
            this.label36.TabIndex = 4;
            this.label36.Text = "Suhu air tanpa kontrol :";
            // 
            // zedGraphControlFuzzy
            // 
            this.zedGraphControlFuzzy.AutoScroll = true;
            this.zedGraphControlFuzzy.BackColor = System.Drawing.Color.White;
            this.zedGraphControlFuzzy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.zedGraphControlFuzzy.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zedGraphControlFuzzy.ForeColor = System.Drawing.Color.SteelBlue;
            this.zedGraphControlFuzzy.IsAutoScrollRange = true;
            this.zedGraphControlFuzzy.IsShowHScrollBar = true;
            this.zedGraphControlFuzzy.IsShowVScrollBar = true;
            this.zedGraphControlFuzzy.Location = new System.Drawing.Point(405, 91);
            this.zedGraphControlFuzzy.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.zedGraphControlFuzzy.Name = "zedGraphControlFuzzy";
            this.zedGraphControlFuzzy.ScrollGrace = 0D;
            this.zedGraphControlFuzzy.ScrollMaxX = 0D;
            this.zedGraphControlFuzzy.ScrollMaxY = 0D;
            this.zedGraphControlFuzzy.ScrollMaxY2 = 0D;
            this.zedGraphControlFuzzy.ScrollMinX = 0D;
            this.zedGraphControlFuzzy.ScrollMinY = 0D;
            this.zedGraphControlFuzzy.ScrollMinY2 = 0D;
            this.zedGraphControlFuzzy.SelectModifierKeys = System.Windows.Forms.Keys.None;
            this.zedGraphControlFuzzy.Size = new System.Drawing.Size(390, 400);
            this.zedGraphControlFuzzy.TabIndex = 103;
            this.zedGraphControlFuzzy.Load += new System.EventHandler(this.zedGraphControlFuzzy_Load);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(411, 497);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 106;
            this.label2.Text = "Set point :";
            // 
            // labelSetPoint
            // 
            this.labelSetPoint.AutoSize = true;
            this.labelSetPoint.BackColor = System.Drawing.Color.Transparent;
            this.labelSetPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSetPoint.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelSetPoint.Location = new System.Drawing.Point(557, 497);
            this.labelSetPoint.Name = "labelSetPoint";
            this.labelSetPoint.Size = new System.Drawing.Size(19, 20);
            this.labelSetPoint.TabIndex = 107;
            this.labelSetPoint.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(616, 497);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 20);
            this.label3.TabIndex = 108;
            this.label3.Text = "°C";
            // 
            // verticalProgressBarLevelAir
            // 
            this.verticalProgressBarLevelAir.BorderStyle = VerticalProgressBar.BorderStyles.Classic;
            this.verticalProgressBarLevelAir.Color = System.Drawing.Color.Blue;
            this.verticalProgressBarLevelAir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verticalProgressBarLevelAir.Location = new System.Drawing.Point(338, 500);
            this.verticalProgressBarLevelAir.Maximum = 6;
            this.verticalProgressBarLevelAir.Minimum = 0;
            this.verticalProgressBarLevelAir.Name = "verticalProgressBarLevelAir";
            this.verticalProgressBarLevelAir.Size = new System.Drawing.Size(59, 65);
            this.verticalProgressBarLevelAir.Step = 1;
            this.verticalProgressBarLevelAir.Style = VerticalProgressBar.Styles.Solid;
            this.verticalProgressBarLevelAir.TabIndex = 109;
            this.verticalProgressBarLevelAir.Value = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(194, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(453, 32);
            this.label4.TabIndex = 110;
            this.label4.Text = "TEKNIK AERASI BUATAN PADA TANAMAN HIDROPONIK PASIF\r\nBERDASARKAN MONITORING DAN KO" +
                "NTROL SUHU AIR\r\n";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Terminal.Properties.Resources.logo_pens;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::Terminal.Properties.Resources.Hima_Elka_besar_585x585;
            this.pictureBox1.Location = new System.Drawing.Point(713, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 111;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(335, 568);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 112;
            this.label5.Text = "Level air";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(649, 497);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 20);
            this.label12.TabIndex = 113;
            this.label12.Text = "OCR :";
            // 
            // labelOCR
            // 
            this.labelOCR.AutoSize = true;
            this.labelOCR.BackColor = System.Drawing.Color.Transparent;
            this.labelOCR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOCR.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelOCR.Location = new System.Drawing.Point(716, 497);
            this.labelOCR.Name = "labelOCR";
            this.labelOCR.Size = new System.Drawing.Size(19, 20);
            this.labelOCR.TabIndex = 114;
            this.labelOCR.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 697);
            this.ControlBox = false;
            this.Controls.Add(this.labelOCR);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.verticalProgressBarLevelAir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelSetPoint);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelDeltaError);
            this.Controls.Add(this.labelError);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelLevelAir);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.labelSuhuAir);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.labelSuhuLingkungan);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.zedGraphControlFuzzy);
            this.Controls.Add(this.zedGraphControlSuhuAir);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.shapeContainer1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Final Project 2015 V 1.0";
            this.TransparencyKey = System.Drawing.Color.Gold;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        //private Tao.Platform.Windows.SimpleOpenGlControl simpleOpenGlControl1;
        //private G05U_Control.Roll roll1;
        //private G05U_Control.Yaw yaw1;
        private System.Windows.Forms.Label label23;
        //private G05U_Control.Pitch pitch1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timerTanggal;
        private System.Windows.Forms.Label labelSuhuAir;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button bOpenPort;
        private System.Windows.Forms.Button bStart;
        private System.Windows.Forms.ComboBox comboBoxCOM;
        private System.Windows.Forms.Button bExit;
        private System.Windows.Forms.Button buttonPause;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.ProgressBar progressBarIndikator;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private System.Windows.Forms.Button buttonSaveData;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private ZedGraph.ZedGraphControl zedGraphControlSuhuAir;
        private System.Windows.Forms.Button buttonClearData;
        private System.Windows.Forms.Timer timerGraphTGS;
        private System.Windows.Forms.Button buttonClosePort;
        private System.Windows.Forms.Timer timerRequestData;
        private System.Windows.Forms.RichTextBox richTextBoxDataReceived;
        private System.Windows.Forms.RichTextBox richTextBoxDataSaved;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelLevelAir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelError;
        private System.Windows.Forms.Label labelDeltaError;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label labelSuhuLingkungan;
        private System.Windows.Forms.Label label36;
        private ZedGraph.ZedGraphControl zedGraphControlFuzzy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelSetPoint;
        private System.Windows.Forms.Label label3;
        private VerticalProgressBar.VerticalProgressBar verticalProgressBarLevelAir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelOCR;
    }
}

